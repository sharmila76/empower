<?php
$manifest = array(
  'acceptable_sugar_versions' => array ( "exact_matches" => array (), 
  "regex_matches" => array (  0=>"4\\.5\\.*", 1 => "4\\.2\\.*" , 2 => "4\\.0\\.*" , 3=> "3\\.5\\.*" )),
	'acceptable_sugar_flavors' => array (
		'OS',
	),
	'name'			=> 'UtahLifeElevated',
	'description'		=> 'This is the original Sugar theme, modified for Utah Tourism',
	'author'		=> 'RTS',
	'published_date'	=> '2007/02/24',
	'version'		=> '0.1',
	'type'			=> 'theme',
	
	'is_uninstallable'	=> true,

	'copy_files' 		=> array (
		'from_dir' => 'Utah',
		'to_dir' => 'themes/Utah',
		'force_copy' => array (
		),
	),
);

?>
