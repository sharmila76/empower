<?php
$manifest = array(
  'acceptable_sugar_versions' => array ( "exact_matches" => array (), 
  "regex_matches" => array (  0=>"4\\.5\\.*", 1 => "4\\.2\\.*" , 2 => "4\\.0\\.*" , 3=> "3\\.5\\.*" )),
	'acceptable_sugar_flavors' => array (
		'OS',
	),
	'name'			=> 'SugarRTL',
	'description'		=> 'This is the original Sugar theme, modified for RTL',
	'author'		=> 'IT Synergy',
	'published_date'	=> '2007/04/13',
	'version'		=> '0.9.6',
	'type'			=> 'theme',
	
	'is_uninstallable'	=> true,

	'copy_files' 		=> array (
		'from_dir' => 'SugarRTL',
		'to_dir' => 'themes/SugarRTL',
		'force_copy' => array (
		),
	),
);

?>
