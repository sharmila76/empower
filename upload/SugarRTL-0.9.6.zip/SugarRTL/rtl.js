/**
 * SugarRTL theme
 * This file overrides HTML attributes there are impossible to override using CSS.
 *
 * Copyright 2007 (c) IT Synergy.
 *
 * This work is licensed under GPL version 2 or later.
 */

SUGAR.themes.rtl = function () {
	var $D = YAHOO.util.Dom;
	var $ = $D.get;

	return {
		init: function() {
			// My account
			this.myaccount();

			// dashlets and help
			this.dashlets();

			// ListView
			this.listview()
			
			// Calendar
			this.calendar()
			
			// Minutes/Hours
			this.switch_minutes_hours()
		},

		myaccount: function () {
			tabs = $D.getElementsByClassName('tabDetailView');
			for (i=0; i<tabs.length; i++) {
				heads = tabs[i].getElementsByTagName('th');
				for (j=0; j<heads.length; j++) {
					heads[j].setAttribute('align', 'right');
				}
			}
		},
		
		dashlets: function () {
			dashlet_td = $('add_dashlets');
			if (dashlet_td) {
				dashlet_td.parentNode.setAttribute('align', 'right');
				help_td = dashlet_td.parentNode.nextSibling;
				while (help_td && help_td.nodeType != 1) {
					help_td = help_td.nextSibling;
				}
				if (help_td && help_td.nodeType == 1) {
					help_td.setAttribute('align', 'left');
				}
			}

		},

		listview: function () {
			listview = $D.getElementsByClassName('listViewThS1');
			for (i=0; i<listview.length; i++) {
				div = listview[i].getElementsByTagName('div')[0];
				if (typeof div != 'undefined') {
					div.setAttribute('align', 'right');
				}
			}
			
			listview = $D.getElementsByClassName('oddListRowS1').concat($D.getElementsByClassName('evenListRowS1'));
			for (i=0; i<listview.length; i++) {
				listview[i].setAttribute('align', 'right');
			}
			
			pagination = $D.getElementsByClassName('listViewPaginationTdS1');
			for (i=0; i<pagination.length; i++) {
				pagination[i].setAttribute('align', 'right');
			}
			if ($('listViewPaginationButtons')) {
				$('listViewPaginationButtons').setAttribute('align', 'left');
			}
			
		},

		calendar: function () {
			next = $D.getElementsByClassName('monthFooterNext')[0];
			if (next) {
				next.setAttribute('align', 'left');
			}
		},

		switch_minutes_hours: function () {
			// Switch Hours/Minutes in Edit
			var hours = document.getElementsByName('duration_hours')[0];
			var minutes = document.getElementsByName('duration_minutes')[0];
			if (hours && minutes) {
				hours = hours.parentNode.replaceChild(minutes.cloneNode(true), hours);
				minutes.parentNode.replaceChild(hours, minutes);
			}
			hours = document.getElementsByName('time_hour_start')[0];
			minutes = document.getElementsByName('time_minute_start')[0];
			if (hours && minutes) {
				hours = hours.parentNode.replaceChild(minutes.cloneNode(true), hours);
				minutes.parentNode.replaceChild(hours, minutes);
			}
			
			// Switch Hours/Minutes in View
			// Some tree traversing needs to be done as Sugar doesn't flag
			// elements with enough classes or id(s)
			var elements = $D.getElementsByClassName("tabDetailView");
			for (var i = 0; i < elements.length; i++) {
				var time_elements = $D.getElementsBy(function (elem) {
					return elem.getAttribute('sugar') == 'slot5b';
				}, 'span', elements[i]);

				for (var j = 0; j < time_elements.length; j++) {
					if (time_elements[j].textContent) text = time_elements[j].textContent;
					if (time_elements[j].innerText) text = time_elements[j].innerText;

					// Real switching happens here..
					var text = text.split(' ')[1] + text.split(' ')[0];

					if (time_elements[j].textContent) time_elements[j].textContent = text;
					if (time_elements[j].innerText) time_elements[j].innerText = text;
				}
			}

			// Switch Hours/Minutes in Main Page
			// the dashlet id is used for traversing even though it's not known how
			// reliable it's, cannot find any other way to cut through the way to the element
			var calls_dashlet = document.getElementById("dashlet_6ede1316-48c1-210e-65d1-45e2b6972b64");
			if (calls_dashlet) {
				var time_elements = $D.getElementsBy(function (elem) {
					return elem.getAttribute('sugar') == 'sugar2b';
				}, 'span', calls_dashlet);

				for (var j = 0; j < time_elements.length; j++) {
					if (time_elements[j].textContent) text = time_elements[j].textContent;
					if (time_elements[j].innerText) text = time_elements[j].innerText;

					// Trim
					var text = text.replace(/^\s+|\s+$/g,"");
					// Real switching happens here..
					text = text.replace(/(\d*\D*)(\d*\D)/, "$2$1");

					if (time_elements[j].textContent) time_elements[j].textContent = text;
					if (time_elements[j].innerText) time_elements[j].innerText = text;
				}
			}
		}
	}
};

rtl = new SUGAR.themes.rtl();
YAHOO.util.Event.on(window, "load", rtl.init, rtl, true);
