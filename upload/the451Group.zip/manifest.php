<?php
// created: 2006-11-01 16:00:00
$manifest = array (
  'acceptable_sugar_versions' =>
  array (
    'exact_matches' =>
    array (
    ),
    'regex_matches' =>
    array (
    	0 => '4.[520].[01][a-z]?'
    ),
  ),
  'acceptable_sugar_flavors' =>
  array (
    0 => 'OS',
    1 => 'PRO',
    2 => 'ENT',
  ),
  'name' => 'The 451 Group',
  'description' => 'The 451 Group theme',
  'author' => 'SugarCRM Inc.',
  'published_date' => '2006-11-01 16:00:00',
  'version' => '4.5.0',
  'type' => 'theme',
  'is_uninstallable' => TRUE,
  'icon' => 'the451Group/images/Themes.gif',
  'copy_files' =>
  array (
    'from_dir' => 'the451Group',
    'to_dir' => 'themes/the451Group',
    'force_copy' =>
    array (
    ),
  ),
);
?>