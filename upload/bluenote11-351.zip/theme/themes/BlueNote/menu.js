/*****************************************************************************
 * The contents of this file are subject to the RECIPROCAL PUBLIC LICENSE
 * Version 1.1 ("License"); You may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * http://opensource.org/licenses/rpl.php. Software distributed under the
 * License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND,
 * either express or implied.
 *
 * You may:
 * a) Use and distribute this code exactly as you received without payment or
 *    a royalty or other fee.
 * b) Create extensions for this code, provided that you make the extensions
 *    publicly available and document your modifications clearly.
 * c) Charge for a fee for warranty or support or for accepting liability
 *    obligations for your customers.
 *
 * You may NOT:
 * a) Charge for the use of the original code or extensions, including in
 *    electronic distribution models, such as ASP (Application Service
 *    Provider).
 * b) Charge for the original source code or your extensions other than a
 *    nominal fee to cover distribution costs where such distribution
 *    involves PHYSICAL media.
 * c) Modify or delete any pre-existing copyright notices, change notices,
 *    or License text in the Licensed Software
 * d) Assert any patent claims against the Licensor or Contributors, or
 *    which would in any way restrict the ability of any third party to use the
 *    Licensed Software.
 *
 * You must:
 * a) Document any modifications you make to this code including the nature of
 *    the change, the authors of the change, and the date of the change.
 * b) Make the source code for any extensions you deploy available via an
 *    Electronic Distribution Mechanism such as FTP or HTTP download.
 * c) Notify the licensor of the availability of source code to your extensions
 *    and include instructions on how to acquire the source code and updates.
 * d) Grant Licensor a world-wide, non-exclusive, royalty-free license to use,
 *    reproduce, perform, modify, sublicense, and distribute your extensions.
 *
 * The Original Code is: AnySoft Informatica
 *                       Marcelo Leite (aka Mr. Milk)
 *                       2005-10-01 mrmilk@anysoft.com.br
 *
 * The Initial Developer of the Original Code is AnySoft Informatica Ltda.
 * Portions created by AnySoft are Copyright (C) 2005 AnySoft Informatica Ltda
 * All Rights Reserved.
 ********************************************************************************/

		  var init = false;
		  var autohide = false;
		  var togglesize = 25;
		  var menushown = true;
		  var menusize = 0;

		  var turn = 0;
		  var goup = 1;
		  var link = 0;
		  var tid;

		  function nostatus()
		  {
			  window.status="";
			  return true;
		  }

		  function disable_status()
		  {
			  return true;

			  for(var count=0;count<document.links.length;count++)
			  {
				  el = document.links[count];
				  if (el.attachEvent) {
					  el.attachEvent("onmouseover", nostatus);
					  el.attachEvent("onclick", setstatus);
					  el.attachEvent("onfocus", nostatus);
				  }
				  else if (el.addEventListener) {
					  el.addEventListener("mouseover", nostatus, true);
					  el.addEventListener("click", setstatus, true);
					  el.addEventListener("focus", nostatus, true);
				  }
				  else {
	              el["onmousemove"] = nostatus;
	              el["onclick"] = setstatus;
	              el["onfocus"] = nostatus;
				  }
			  }
			  for(var f=0;f<document.forms.length;f++)
			  {
				  for(var count=0;count<document.forms[f].elements.length;count++)
				  {
					  if(document.forms[f].elements[count].type.toLowerCase() == "submit")
					  {
						  el = document.forms[f].elements[count];
						  if (el.attachEvent) {
							  el.attachEvent("onclick", setstatus);
						  }
						  else if (el.addEventListener) {
							  el.addEventListener("click", setstatus, true);
						  }
						  else {
	                    el["onclick"] = setstatus;
						  }
					  }
				  }
			  }
		  }

		  function setstatus()
		  {
			  return true;

			  if(window.status != "CallRooM CRM")
			  {
				  var str = '';
				  for(i=0;i<=turn;i++)
					  str = str+".";

				  turn = turn+goup;
				  if(turn==20)
					  goup = -1;
				  else if(turn==0)
					  goup = 1;

				  window.status = "Loading, wait"+str;
				  tid = window.setTimeout("setstatus()", 100);
			  }
			  else
			  {
				  window.clearTimeout(tid);
				  window.status = '';
				  return true;
			  }
		  }

		  function initmenu()
		  {
				init = true;
				disable_status();
				window.status = "CallRooM CRM";

				var el = document.body;

				if (el.attachEvent) { // IE
					 el.attachEvent("onmousemove", setmenu);
				}
				else if (el.addEventListener) { // Gecko / W3C
					 el.addEventListener("mousemove", setmenu, true);
				}
				else {
	             el["onmousemove"] = setmenu;
				}

				var mn = document.getElementById("menu");
				menusize = mn.offsetWidth;

				if(document.cookie.match("login_action=1"))
				{
					 hidemenu();
					 document.cookie = "login_action=0";
				}
				else if(document.cookie.match("sugar_autohide=1"))
				{
					 hidemenu();
					 autohide = true;
				}

				mn = document.getElementById("menuicon");
				//mn.style.background = autohide ? "#efefef" : "#dfdfdf";
				if(autohide)
					mn.src = mn.src.replace("/unpin.gif","/pin.gif");
				else
					mn.src = mn.src.replace("/pin.gif","/unpin.gif")
		  }

		  function setmenu(el)
		  {
				if(!init || menusize == 0)
					 initmenu();

				if(autohide)
				{
					 if((el.clientX <= togglesize))
					 {
						  if(!menushown)
								showmenu();
					 }
					 else if(el.clientX > menusize)
					 {
						  if(menushown)
								hidemenu();
					 }
				}
		  }

		  function toggleauto() {

				var layer = document.getElementById("menuicon");
				//layer.style.background = autohide ? "#dfdfdf" : "#efefef";
				if(!autohide)
					layer.src = layer.src.replace("/unpin.gif","/pin.gif")
				else
					layer.src = layer.src.replace("/pin.gif","/unpin.gif");

				autohide = (!autohide);
				document.cookie = "sugar_autohide=" + (autohide ? "1" : "0");
		  }

		  function hidemenu() {

				var mn = document.getElementById("menu");
				mn.style.display = "none";
				var wc = document.getElementById("button_gap");
				wc.style.display = "none";
				wc = document.getElementById("welcome");
				wc.style.display = "none";

				menushown = false;
		  }

		  function showmenu() {

				var mn = document.getElementById("menu");
				mn.style.display = "";
				var wc = document.getElementById("button_gap");
				wc.style.display = "";
				wc = document.getElementById("welcome");
				wc.style.display = "";

				menushown = true;
		  }

		  function printme() {

				var el = document.getElementById("noprint1");
				if(el.style.display != "none") {
					el.style.display = "none";
					el = document.getElementById("noprint2");
					el.style.display = "none";
					el = document.getElementById("noprint3");
					el.style.display = "none";
					el = document.getElementById("noprint4");
					el.style.display = "none";
					el = document.getElementById("noprint5");
					el.style.display = "none";
					el = document.getElementById("noprint6");
					el.style.display = "none";
					el = document.getElementById("menu");
					el.style.display = "none";
				}
				else {
					el.style.display = "";
					el = document.getElementById("noprint2");
					el.style.display = "";
					el = document.getElementById("noprint3");
					el.style.display = "";
					el = document.getElementById("noprint4");
					el.style.display = "";
					el = document.getElementById("noprint5");
					el.style.display = "";
					el = document.getElementById("noprint6");
					el.style.display = "";
					el = document.getElementById("menu");
					el.style.display = "";
				}

		  }
