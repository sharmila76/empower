<?php
/*****************************************************************************
 * The contents of this file are subject to the RECIPROCAL PUBLIC LICENSE
 * Version 1.1 ("License"); You may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * http://opensource.org/licenses/rpl.php. Software distributed under the
 * License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND,
 * either express or implied.
 *
 * You may:
 * a) Use and distribute this code exactly as you received without payment or
 *    a royalty or other fee.
 * b) Create extensions for this code, provided that you make the extensions
 *    publicly available and document your modifications clearly.
 * c) Charge for a fee for warranty or support or for accepting liability
 *    obligations for your customers.
 *
 * You may NOT:
 * a) Charge for the use of the original code or extensions, including in
 *    electronic distribution models, such as ASP (Application Service
 *    Provider).
 * b) Charge for the original source code or your extensions other than a
 *    nominal fee to cover distribution costs where such distribution
 *    involves PHYSICAL media.
 * c) Modify or delete any pre-existing copyright notices, change notices,
 *    or License text in the Licensed Software
 * d) Assert any patent claims against the Licensor or Contributors, or
 *    which would in any way restrict the ability of any third party to use the
 *    Licensed Software.
 *
 * You must:
 * a) Document any modifications you make to this code including the nature of
 *    the change, the authors of the change, and the date of the change.
 * b) Make the source code for any extensions you deploy available via an
 *    Electronic Distribution Mechanism such as FTP or HTTP download.
 * c) Notify the licensor of the availability of source code to your extensions
 *    and include instructions on how to acquire the source code and updates.
 * d) Grant Licensor a world-wide, non-exclusive, royalty-free license to use,
 *    reproduce, perform, modify, sublicense, and distribute your extensions.
 *
 * The Original Code is: AnySoft Informatica
 *                       Marcelo Leite (aka Mr. Milk)
 *                       2005-10-01 mrmilk@anysoft.com.br
 *
 * The Initial Developer of the Original Code is AnySoft Informatica Ltda.
 * Portions created by AnySoft are Copyright (C) 2005 AnySoft Informatica Ltda
 * All Rights Reserved.
 ********************************************************************************/
require_once('XTemplate/xtpl.php');
require_once("data/Tracker.php");
require_once("include/utils.php");
require_once("include/globalControlLinks.php");

global $currentModule;
global $moduleList;
global $theme;
global $max_tabs;
global $app_strings;

$theme_path="themes/".$theme."/";
$image_path=$theme_path."images/";
$charset = isset($app_strings['LBL_CHARSET']) ? $app_strings['LBL_CHARSET'] : $sugar_config['default_charset'];
$module_path = "modules/".$currentModule."/";
$user = $current_user->first_name != '' ? $current_user->first_name : $current_user->user_name;
$query = isset($_REQUEST['query_string']) ? $_REQUEST['query_string'] : '';
$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : "";
$setfocus = $action == "EditView" || $action == "Login" ? 'onload="set_focus()"' : '';
$original_module = $currentModule;

require_once($theme_path.'layout_utils.php');
require($theme_path.'config.php');
require_once($theme_path."menudefs.php");

if(isset($_REQUEST["dropdown_select"]) && $_REQUEST["dropdown_select"]=="menu_aqua" && isset($_REQUEST["reset"])) {
  global $app_list_strings;
  global $current_language;
  require_once("modules/Administration/Common.php");
  require_once('config.php');
  create_dropdown_type("menu_aqua", $current_language);
  dropdown_item_delete("menu_aqua", $current_language, 0);
  $i=0;
  foreach($menu_defs as $m=>$v) {
    if(isset($local_strings[$current_language][$m]))
  	  dropdown_item_insert("menu_aqua", $current_language, $i, $m, $local_strings[$current_language][$m]);
    else
      dropdown_item_insert("menu_aqua", $current_language, $i, $m, $m);
    $i++;
  }
}

$xtpl = new XTemplate ($theme_path."header.html");
$xtpl->assign("APP", $app_strings);
$xtpl->assign("THEME", $theme);
$xtpl->assign("IMAGE_PATH", $image_path);
$xtpl->assign("PRINT_URL", "index.php?".$GLOBALS['request_string']);
$xtpl->assign("MODULE_NAME", $currentModule);
$xtpl->assign("DATE", date("Y-m-d"));
$xtpl->assign("LBL_CHARSET", $charset);
$xtpl->assign("CURRENT_USER", $user);
$xtpl->assign("CURRENT_USER_ID", $current_user->id);
$xtpl->assign("ONLOAD", $setfocus);

$activities = array("Calls", "Meetings", "Tasks", "Notes");
if(in_array("Calendar",$moduleList)) {
	$cal_activities= array("Calls","Meetings");
	if(in_array($currentModule,$cal_activities)) {
		$currentModule = "Calendar";
	}
  elseif(in_array($currentModule,$activities)) {
		$currentModule = "Activities";
	}
}
elseif(in_array($currentModule,$activities)) {
	$currentModule = "Activities";
}
$menu_tree = array();
$tracker = new Tracker();
$history = $tracker->get_recently_viewed($current_user->id);
$current_row = 1;
if(count($history) > 0) {
	foreach($history as $row)	{
    $menu_tree['Recent'][$row['item_summary']]['icon']   = get_image($image_path.$row['module_name'],'border="0" align="absmiddle" alt="'.$row['item_summary'].'"');
    $menu_tree['Recent'][$row['item_summary']]['label']  = $row['item_summary'];
    $menu_tree['Recent'][$row['item_summary']]['action'] = $row['item_summary'];
    $menu_tree['Recent'][$row['item_summary']]['url']    = "index.php?module=$row[module_name]&action=DetailView&record=$row[item_id]";
    $menu_tree['Recent'][$row['item_summary']]['module'] = $row['module_name'];
  	if($current_row==12) break;
    $current_row++;
	}
}
foreach($global_control_links as $key => $value) {
  foreach ($value as $linkattribute => $attributevalue) {
    if($linkattribute == 'linkinfo') {
      foreach ($attributevalue as $label => $url) {
        $menu_tree['Global'][$label]['icon']   = "";
        $menu_tree['Global'][$label]['label']  = $label;
        $menu_tree['Global'][$label]['action'] = $label;
        $menu_tree['Global'][$label]['url']    = $url;
        $menu_tree['Global'][$label]['module'] = "Administration";
      }
    }
  }
}
if($current_user->is_admin=="on") {
  $menu_tree['Aqua']["Reset"]['icon'] = "";
  $menu_tree['Aqua']["Reset"]['module'] = "";
  $menu_tree['Aqua']["Reset"]['action'] = "";
  $menu_tree['Aqua']["Reset"]['label'] = isset($local_strings[$current_language]['Reset']) ? $local_strings[$current_language]['Reset'] : "Reset and Localize Menus";
  $menu_tree['Aqua']["Reset"]['url']  = "index.php?dropdown_select=menu_aqua&reset=true&language_select=$current_language&action=index&query=true&module=Dropdown&button=Select";
  $menu_defs["File"][] = "Aqua";
}

$curr_mod_strings = $mod_strings;
$modListHeader = $action=='Login' ? array() : get_val_array(query_module_access_list($current_user));

$is_submodule = true;
if(in_array($currentModule, $mod_exclude))
  $is_submodule = false;
else {
  foreach($menu_defs as $menu=>$mods) {
    foreach($mods as $key=>$mod) {
      if($mod==$currentModule) {
        $is_submodule = false;
        break 2;
      }
    }
  }
}
if($is_submodule) {
  $menu_defs["Shortcuts"][] = $currentModule;
  $menu_defs["Shortcuts"][] = "Recent";
  if(!in_array($currentModule, $modListHeader))
    $modListHeader[] = $currentModule;
}
else {
  $menu_defs["Shortcuts"][] = "Recent";
}

foreach($modListHeader as $module_name) {
  $mod_label = isset($app_list_strings['moduleList'][$module_name]) ? $app_list_strings['moduleList'][$module_name] : $module_name;
  if(!in_array($module_name, $mod_exclude)) {
    $mod_strings = return_module_language($current_language, $module_name);
    load_menu("modules/$module_name/");
    foreach($module_menu as $menu_item) {
      $modn = isset($menu_item[3]) && $menu_item[3]!="" ? $menu_item[3] : $module_name;
      $menu_tree[$module_name][$menu_item[1]]['icon']   = get_image($image_path.$menu_item[2]," title='".$menu_item[1]."' border='0' align='absmiddle'")."";
      $menu_tree[$module_name][$menu_item[1]]['label']  = $menu_item[1];
      $menu_tree[$module_name][$menu_item[1]]['action'] = $menu_item[2];
      $menu_tree[$module_name][$menu_item[1]]['url']    = $menu_item[0];
      $menu_tree[$module_name][$menu_item[1]]['module'] = $modn;
    }
  }
  if(!$is_submodule || $module_name!=$currentModule) {
    $icon = get_image($image_path.$module_name, "' border='0' align='absmiddle' alt='".$mod_label."'");
    $xtpl->assign("SIDE_LABEL", $mod_label);
    $xtpl->assign("SIDE_URL", "index.php?module=$module_name&action=index");
    $xtpl->assign("SIDE_ICON", $icon);
  	$xtpl->parse("main.sidebar");
	}
}

//write_array_to_file("menu", $menu_tree, "themes/Sugar/menu_tree.php");
$mod_strings = $curr_mod_strings;
if($action!="Login") {
  $xtpl->assign("TITLE", $app_strings['LBL_SEARCH']);
  $xtpl->assign("SEARCH", $query);
  foreach($menu_defs as $menu => $mods) {
    $first_time = true;
    foreach($mods as $mod) {
      if(isset($menu_tree[$mod])) {
        $popup = $menu_tree[$mod];
        if(!$first_time) {
          $xtpl->assign("POPUP_URL", "");
          $xtpl->assign("POPUP_ICON", "");
          $xtpl->assign("POPUP_LABEL", "&nbsp;");
          $xtpl->assign("POPUP_ID", "separator");
          $xtpl->assign("POPUP_ITEMID", "separator");
          $xtpl->assign("ICON_CLASS", "popup_icon_sep");
          $xtpl->assign("ITEM_CLASS", "popup_item_sep");
          $xtpl->parse("main.popupmenu.popupitem");
        }
        foreach($popup as $menu_popup => $menu_item) {
          if(!preg_match("/action=index/", $menu_item['url']))
      	    $xtpl->assign("POPUP_ICON", $menu_item['icon']);
          else
            $xtpl->assign("POPUP_ICON", "");
          $xtpl->assign("POPUP_LABEL", $menu_item['label']);
      	  $xtpl->assign("POPUP_URL", $menu_item['url']);
          $xtpl->assign("POPUP_ID", $menu_item['module']);
          $xtpl->assign("POPUP_ITEMID", $menu_item['module'].$menu_item['action']);
          $xtpl->assign("ICON_CLASS", "popup_icon");
          $xtpl->assign("ITEM_CLASS", "popup_item");
      		$xtpl->parse("main.popupmenu.popupitem");
        }
        $first_time = false;
      }
    }
    if(!$first_time) {
    	$xtpl->assign("POPUP_ID", $menu);
    	$xtpl->parse("main.popupmenu");

      $menu_lbl = isset($app_list_strings["menu_aqua"][$menu]) ? $app_list_strings["menu_aqua"][$menu] : $menu;
      $xtpl->assign("MENU_LABEL", $menu_lbl);
      $xtpl->assign("MENU_ID", $menu);
      $xtpl->parse("main.menubar");
    }
  }
  foreach($icon_defs as $group => $defs) {
    foreach($defs as $def) {
      if(isset($menu_tree[$def["module"]])) {
        if($def["module"]=="Recent") {
          $items = array_slice($menu_tree['Recent'], 0, $def["items"]);
          foreach($items as $key=>$val) {
            $xtpl->assign("TOOL_ICON", $val["icon"]);
            $xtpl->assign("TOOL_URL", $val["url"]);
            $xtpl->assign("TOOL_CLASS", "tool_item");
            $xtpl->parse("main.toolbar");
          }
        }
        else {
          $item = key(array_slice($menu_tree[$def["module"]], $def["menu_item"]-1, 1));
          $icon = $menu_tree[$def["module"]][$item]["icon"];
          $icon = preg_replace("|/[^/]+\.gif|", "/".$def["icon"].".gif", $icon);
          $xtpl->assign("TOOL_ICON", $icon);
          $xtpl->assign("TOOL_URL", $menu_tree[$def["module"]][$item]["url"]);
          $xtpl->assign("TOOL_CLASS", "tool_item");
          $xtpl->parse("main.toolbar");
        }
      }
    }
    $xtpl->assign("TOOL_CLASS", "tool_sep");
    $xtpl->assign("TOOL_ICON", "");
    $xtpl->assign("TOOL_URL", "");
    $xtpl->parse("main.toolbar");
  }
  $xtpl->assign("WIN_SPACER", get_image($image_path."blank", " border='0' align='absmiddle'", 22, 18));
  $xtpl->assign("USER_LOGOFF", "Logoff ".$user);
}
require_once("modules/".$currentModule."/Forms.php");
$currentModule = $original_module;
$xtpl->assign("MODULE_NAME", $currentModule);
$xtpl->parse("main");
$xtpl->out("main");

?>
