/*****************************************************************************
 * The contents of this file are subject to the RECIPROCAL PUBLIC LICENSE
 * Version 1.1 ("License"); You may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 * http://opensource.org/licenses/rpl.php. Software distributed under the
 * License is distributed on an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND,
 * either express or implied.
 *
 * You may:
 * a) Use and distribute this code exactly as you received without payment or
 *    a royalty or other fee.
 * b) Create extensions for this code, provided that you make the extensions
 *    publicly available and document your modifications clearly.
 * c) Charge for a fee for warranty or support or for accepting liability
 *    obligations for your customers.
 *
 * You may NOT:
 * a) Charge for the use of the original code or extensions, including in
 *    electronic distribution models, such as ASP (Application Service
 *    Provider).
 * b) Charge for the original source code or your extensions other than a
 *    nominal fee to cover distribution costs where such distribution
 *    involves PHYSICAL media.
 * c) Modify or delete any pre-existing copyright notices, change notices,
 *    or License text in the Licensed Software
 * d) Assert any patent claims against the Licensor or Contributors, or
 *    which would in any way restrict the ability of any third party to use the
 *    Licensed Software.
 *
 * You must:
 * a) Document any modifications you make to this code including the nature of
 *    the change, the authors of the change, and the date of the change.
 * b) Make the source code for any extensions you deploy available via an
 *    Electronic Distribution Mechanism such as FTP or HTTP download.
 * c) Notify the licensor of the availability of source code to your extensions
 *    and include instructions on how to acquire the source code and updates.
 * d) Grant Licensor a world-wide, non-exclusive, royalty-free license to use,
 *    reproduce, perform, modify, sublicense, and distribute your extensions.
 *
 * The Original Code is: AnySoft Informatica
 *                       Marcelo Leite (aka Mr. Milk)
 *                       2005-10-01 mrmilk@anysoft.com.br
 *
 * The Initial Developer of the Original Code is AnySoft Informatica Ltda.
 * Portions created by AnySoft are Copyright (C) 2005 AnySoft Informatica Ltda
 * All Rights Reserved.
 ********************************************************************************/
var curr_popup = null;
var curr_menu  = null;
var browser_width = null;
var is = new Is();

function track_menu(mn, out) {
  if(!browser_width)
    browser_width = window_width();
  if(!curr_popup)
    mn.className = out=='out' ? "menu_item" : "menu_focus";
  else if(mn.id+"Popup"!=curr_popup.id) {
    if(out=='in')
      popitup(mn, true);
    else
      mn.className = out=='out' ? "menu_item" : "menu_focus";
  }
}
function track_popup(item, out) {
  if(item.id=="separatorHandle") return true;
  cells = item.getElementsByTagName('td');
  cells[0].className = out=='out' ? "popup_icon" : "icon_focus";
  cells[1].className = out=='out' ? "popup_item" : "popup_focus";
  window.status = out=='in' ? item.innerText : "";
}
function track_tool(tb, out) {
  if(!browser_width)
    browser_width = window_width();
  if(tb.className=="tool_sep") return true;
  tb.className = out=='out' ? "tool_item" : "tool_focus";
}
function url_module(url) {
  url = url.substr(url.indexOf("?")+1);
  var fields = url.split("&");
  for(var i=0;i<fields.length;i++) {
    var els = fields[i].split("=");
    if(els[0].toLowerCase()=="module") {
      return els[1];
      break;
    }
  }
  return "";
}
function resize(max) {
  var header = document.getElementById("header");
  var sidebar = document.getElementById("sidebar");
  header.style.display = max==1 ? "none" : "";
  sidebar.style.display = max==1 ? "none" : "";
  window.focus();
}
function run_popup(url) {
  var module = url_module(url);
  if(module!="") {
    var subpanel = document.getElementById("formform"+module);
    if(subpanel!=undefined && url.match(/action=EditView/i)) {
      subpanel.submit();
      return true;
    }
    else
      window.location = url;
  }
  else
    window.location = url;
}
function popitup(mn, force) {
  if(force==undefined) {
    ev = !window.event ? arguments.callee.caller.arguments[0] : window.event;
  	el = ev.srcElement || ev.currentTarget || ev.target;
    if(is.ie)
      ev.cancelBubble = true;
    else
      ev.stopPropagation();
  }
  if(curr_popup && curr_menu.id==mn.id) {
    close_popup(true);
  }
  else {
    var top = 24;
    var hdr = document.getElementById("header");
    if(hdr.style.display!="none") top = parseInt(hdr.offsetHeight)+24;
    if(el.className!='menu_active' || force!=undefined) close_popup();
    mn.className = "menu_active";
    var pop = document.getElementById(mn.id+"Popup");
    var mnWidth = 0;
    var popWidth = 0;
    if(pop) {
      var p = mn;
  		if(left==undefined || left==0) {
  		  var left = 0;
  		  while(p && p.tagName.toLowerCase()!='body') {
  			 left += p.offsetLeft;
  			 p = p.offsetParent;
  		  }
  		}
  		if(left+popWidth>browser_width)
  			left = left-popWidth+mnWidth;
			pop.style.display='block';
			pop.style.visibility='visible';
		  if (left >=0 && top >= 0) {
  			pop.style.left = left+'px';
  			pop.style.top = top+'px';
  		}
  		curr_menu = mn;
  		curr_popup = pop;
  	}
  }
}
function close_popup(keepfocus) {
  if(curr_popup) {
    curr_popup.style.visibility = "hidden";
    curr_menu.className = keepfocus!=undefined ? "menu_focus" : "menu_item";
    curr_popup = null;
  }
}
function printme() {
	var el = document.getElementById("menubar");
	if(el.style.display != "none") {
		el.style.display = "none";
		el = document.getElementById("header");
		el.style.display = "none";
		el = document.getElementById("sidebar");
		el.style.display = "none";
		el = document.getElementById("menubar");
		el.style.display = "none";
		el = document.getElementById("toolbar");
		el.style.display = "none";
		el = document.getElementById("footer");
		el.style.display = "none";
	}
	else {
		el.style.display = "";
		el = document.getElementById("header");
		el.style.display = "";
		el = document.getElementById("sidebar");
		el.style.display = "";
		el = document.getElementById("menubar");
		el.style.display = "";
		el = document.getElementById("toolbar");
		el.style.display = "";
		el = document.getElementById("footer");
		el.style.display = "";
	}
}
function Is() {
  var agt = navigator.userAgent.toLowerCase();
  this.major = parseInt(navigator.appVersion);
  this.minor = parseFloat(navigator.appVersion);
  this.nav = ((agt.indexOf('mozilla')!=-1) && (agt.indexOf('spoofer')==-1) && (agt.indexOf('compatible') == -1) && (agt.indexOf('opera')==-1) && (agt.indexOf('webtv')==-1) && (agt.indexOf('hotjava')==-1));
  this.nav2 = (this.nav && (this.major == 2));
  this.nav3 = (this.nav && (this.major == 3));
  this.nav4 = (this.nav && (this.major == 4));
  this.nav4up = (this.nav && (this.major >= 4));
  this.navonly = (this.nav && ((agt.indexOf(";nav") != -1) || (agt.indexOf("; nav") != -1)));
  this.nav6 = (this.nav && (this.major == 5));
  this.nav6up = (this.nav && (this.major >= 5));
  this.gecko = (agt.indexOf('gecko') != -1);
  this.nav7 = (this.gecko && (this.major >= 5) && (agt.indexOf('netscape/7')!=-1));
  this.moz1 = false;
  this.moz1up = false;
  this.moz1_1 = false;
  this.moz1_1up = false;
  if(this.nav6up) {
    myRegEx = new RegExp("rv:\\d*.\\d*.\\d*");
    myFind = myRegEx.exec(agt);
    if(myFind!=null) {
      var strVersion = myFind.toString();
      strVersion = strVersion.replace(/rv:/,'');
      var arrVersion = strVersion.split('.');
      var major = parseInt(arrVersion[0]);
      var minor = parseInt(arrVersion[1]);
      if (arrVersion[2]) var revision = parseInt(arrVersion[2]);
      this.moz1 = ((major == 1) && (minor == 0));
      this.moz1up = ((major == 1) && (minor >= 0));
      this.moz1_1 = ((major == 1) && (minor == 1));
      this.moz1_1up = ((major == 1) && (minor >= 1));
    }
  }
  this.ie     = ((agt.indexOf("msie") != -1) && (agt.indexOf("opera") == -1));
  this.ie3    = (this.ie && (this.major < 4));
  this.ie4    = (this.ie && (this.major == 4) && (agt.indexOf("msie 4")!=-1) );
  this.ie4up  = (this.ie  && (this.major >= 4));
  this.ie5    = (this.ie && (this.major == 4) && (agt.indexOf("msie 5.0")!=-1) );
  this.ie5_5  = (this.ie && (this.major == 4) && (agt.indexOf("msie 5.5") !=-1));
  this.ie5up  = (this.ie  && !this.ie3 && !this.ie4);
  this.ie5_5up =(this.ie && !this.ie3 && !this.ie4 && !this.ie5);
  this.ie6    = (this.ie && (this.major == 4) && (agt.indexOf("msie 6.")!=-1) );
  this.ie6up  = (this.ie  && !this.ie3 && !this.ie4 && !this.ie5 && !this.ie5_5);
	this.mac    = (agt.indexOf("mac") != -1);
}
function window_width() {
	return (is.ie) ? document.body.clientWidth : window.innerWidth - 16;
}
