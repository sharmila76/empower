<?php
$mod_exclude = array(
  "Home",
  "Calendar",
  "EmailTemplates"
);
$menu_defs = array(
  "File" => array(
    "Global",
  ),
  "Accounts" => array(
    "Accounts",
    "Contacts",
    "Leads",
  ),
  "Activities" => array(
    "Activities",
    "Calendar",
    "Meetings",
    "Calls",
    "Tasks",
    "Notes",
  ),
  "Communication" => array(
    "Emails",
    "ZuckerMail",
    "Documents",
    "ZuckerDocs",
    "DocMerge",
  ),
  "Sales" => array(
    "Opportunities",
    "Quotes",
    "Forecasts",
    "Products",
    "Dashboard",
    "ZuckerReports",
  ),
  "Service" => array(
    "Cases",
    "Bugs",
    "Project",
  ),
  "Marketing" => array(
    "Campaigns",
    "ProspectLists",
  ),
  "Portal" => array(
    "iFrames",
    "Feeds",
  ),
  "Shortcuts" => array(
  ),
);
$icon_defs = array(
  0 => array(
    array(
      "module" => "Accounts",
      "menu_item" => 1,
      "icon" => "CreateAccounts",
    ),
    array(
      "module" => "Contacts",
      "menu_item" => 1,
      "icon" => "CreateContacts",
    ),
    array(
      "module" => "Leads",
      "menu_item" => 1,
      "icon" => "CreateLeads",
    ),
  ),
  1 => array(
    array(
      "module" => "Activities",
      "menu_item" => 2,
      "icon" => "Meetings",
    ),
    array(
      "module" => "Activities",
      "menu_item" => 1,
      "icon" => "Calls",
    ),
    array(
      "module" => "Activities",
      "menu_item" => 3,
      "icon" => "Tasks",
    ),
  ),
  2 => array(
    array(
      "module" => "Activities",
      "menu_item" => 4,
      "icon" => "Notes",
    ),
    array(
      "module" => "Emails",
      "menu_item" => 1,
      "icon" => "Emails",
    ),
  ),
  3 => array(
    array(
      "module" => "Recent",
      "items" => 4,
    ),
  ),
);
$local_strings["pt_br"] = array(
  "File" => "Arquivo",
  "Accounts" => "Empresas",
  "Activities" => "Atividades",
  "Communication" => "Comunica��o",
  "Sales" => "Vendas",
  "Service" => "Servi�os",
  "Marketing" => "Marketing",
  "Portal" => "Portal",
  "Shortcuts" => "Atalhos",
  "Recent" => "Recentes",
  
  "Reset" => "Recriar e Traduzir Menus",
);

?>
