<?php
/**
 * Created by YouAddOn.com.
 * Date: 11/05/13
 */

$manifest = array (
    'acceptable_sugar_versions' =>
    array (
        'exact_matches' =>
        array (
        ),
        'regex_matches' =>
        array (
            0 => '6\.*.*'
        ),
    ),
    'acceptable_sugar_flavors' =>
    array (
        0 => 'OS',
        1 => 'PRO',
        2 => 'ENT',
        3 => 'CE',
    ),
    'name' => 'iSales Theme',
    'description' => 'Theme Created by YouAddon.com',
    'author' => 'YouAddOn',
    'published_date' => '2013-11-05 08:00:00',
    'version' => '1.0',
    'type' => 'theme',
    'is_uninstallable' => TRUE,
    'icon' => '',
    'copy_files' =>
    array (
        'from_dir' => 'iSales',
        'to_dir' => 'themes/iSales',
        'force_copy' =>
        array (
        ),
    ),
);
?>