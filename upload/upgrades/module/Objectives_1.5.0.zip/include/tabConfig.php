<?php

$GLOBALS['tabStructure']["LBL_TABGROUP_OBJECTIVES"] = array (
	'label' => 'LBL_TABGROUP_OBJECTIVES',
	'modules' => array(
		"Home",
		"OBJ_Objectives",
		"OBJ_Indicators",
		"OBJ_Conditions",
	),
);

?>