<?php
// created: 2010-11-23 09:24:15
$dictionary["OBJ_Indicators"]["fields"]["obj_indicators_obj_conditions"] = array (
  'name' => 'obj_indicators_obj_conditions',
  'type' => 'link',
  'relationship' => 'obj_indicators_obj_conditions',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_OBJ_INDICATORS_OBJ_CONDITIONS_FROM_OBJ_CONDITIONS_TITLE',
);
