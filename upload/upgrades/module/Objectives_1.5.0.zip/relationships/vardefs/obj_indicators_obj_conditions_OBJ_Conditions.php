<?php
// created: 2010-11-23 09:24:15
$dictionary["OBJ_Conditions"]["fields"]["obj_indicators_obj_conditions"] = array (
  'name' => 'obj_indicators_obj_conditions',
  'type' => 'link',
  'relationship' => 'obj_indicators_obj_conditions',
  'source' => 'non-db',
  'vname' => 'LBL_OBJ_INDICATORS_OBJ_CONDITIONS_FROM_OBJ_INDICATORS_TITLE',
);
$dictionary["OBJ_Conditions"]["fields"]["obj_indicators_obj_conditions_name"] = array (
  'name' => 'obj_indicators_obj_conditions_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_OBJ_INDICATORS_OBJ_CONDITIONS_FROM_OBJ_INDICATORS_TITLE',
  'save' => true,
  'id_name' => 'indicator_name',
  'link' => 'obj_indicators_obj_conditions',
  'table' => 'obj_indicators',
  'module' => 'OBJ_Indicators',
  'rname' => 'name',
);
