<?php
// created: 2010-11-23 09:24:15
$layout_defs["OBJ_Indicators"]["subpanel_setup"]["obj_indicators_obj_conditions"] = array (
  'order' => 100,
  'module' => 'OBJ_Conditions',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OBJ_INDICATORS_OBJ_CONDITIONS_FROM_OBJ_CONDITIONS_TITLE',
  'get_subpanel_data' => 'obj_indicators_obj_conditions',
  'top_buttons' => array (),
);
