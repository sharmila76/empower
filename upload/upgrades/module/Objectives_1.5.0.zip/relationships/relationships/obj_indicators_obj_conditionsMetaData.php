<?php
// created: 2010-11-23 09:24:15
$dictionary["obj_indicators_obj_conditions"] = array (
  'true_relationship_type' => 'one-to-many',
  'from_studio' => true,
  'relationships' => 
  array (
    'obj_indicators_obj_conditions' => 
    array (
      'lhs_module' => 'OBJ_Indicators',
      'lhs_table' => 'obj_indicators',
      'lhs_key' => 'id',
      'rhs_module' => 'OBJ_Conditions',
      'rhs_table' => 'obj_conditions',
      'rhs_key' => 'id',
      'relationship_type' => 'many-to-many',
      'join_table' => 'obj_indicatj_conditions_c',
      'join_key_lhs' => 'indicator_name',
      'join_key_rhs' => 'obj_indica3cf9ditions_idb',
    ),
  ),
  'table' => 'obj_indicatj_conditions_c',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'id',
      'type' => 'varchar',
      'len' => 36,
    ),
    1 => 
    array (
      'name' => 'date_modified',
      'type' => 'datetime',
    ),
    2 => 
    array (
      'name' => 'deleted',
      'type' => 'bool',
      'len' => '1',
      'default' => '0',
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'indicator_name',
      'type' => 'varchar',
      'len' => 36,
    ),
    4 => 
    array (
      'name' => 'obj_indica3cf9ditions_idb',
      'type' => 'varchar',
      'len' => 36,
    ),
  ),
  'indices' => 
  array (
    0 => 
    array (
      'name' => 'obj_indicatobj_conditionsspk',
      'type' => 'primary',
      'fields' => 
      array (
        0 => 'id',
      ),
    ),
    1 => 
    array (
      'name' => 'obj_indicatobj_conditions_ida1',
      'type' => 'index',
      'fields' => 
      array (
        0 => 'indicator_name',
      ),
    ),
    2 => 
    array (
      'name' => 'obj_indicatobj_conditions_alt',
      'type' => 'alternate_key',
      'fields' => 
      array (
        0 => 'obj_indica3cf9ditions_idb',
      ),
    ),
  ),
);
?>
