<h3>Manage your objectives</h3>
<br/><br/>
After installation you may need to do the following steps:<br/>
<ol>
<li>Quick Repair and Rebuild</li>
<li>Repair JS Files</li>
<li>Clear Browser Cache</li>
<li>Review Your Objective Definitions If This Is Not A First Installation.</li>
</ol>
Development by <i>SYSTEM in MOTION</i> (<a href="http://www.system-in-motion.com">www.system-in-motion.com</a>)<br/>
<br/><br/>
<?php
if (! defined('sugarEntry') || ! sugarEntry)
	die('Not A Valid Entry Point');


function post_install() {
	// clean old relationship metadata
	unlink('custom/metadata/obj_indicators_obj_conditionsMetaData.php');
}
?>