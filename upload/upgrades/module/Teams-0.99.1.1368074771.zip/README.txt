CE Teams - README
version 0.98

Please notify me at sugarcrm@mjvn.net if you use (or try) this module!

This module adds team functionality to *any* module in SugarCRM Community Edition.
It uses the logic hooks to hook into any module to limit access to DetailViews,
EditViews, ListViews and Popups based on the assigned team.
Because it uses the logic hooks it is 100% upgrade safe!

After installation you will find an extra item "Teams" in the
admin panel where you can create teams and add users to them.

As of version 0.97 there is an action "Enable Modules" in the shortcuts menu of
the Teams module.  Simply select the modules you want to have team enabled, save
the changes and then run a Quick Repair twice. *You really need to run it twice*
Tip: Press Ctrl-R on FF or Ctrl-F5 on IE to just run it again after running it once.

The "Enable Modules" action will add team_id and team_name fields to the
selected modules which will team enable them.
The custom logic will check for the presence of these fields and if they
are present enforce the team security when a record is retrieved.
For compatibility with previous versions the custom logic will still check for
and act on custom team_c or team_name_c fields.

NB: Even though "Enable Modules" wille add the field to each selected module *you*
still have to go to Studio and add it to at least the EditView so that users can
assign a team when they create or edit a record.

As of version 0.98 there is an action "Set Default Teams" in the shortcuts menu
that will allow you to set a default team for every user (from the teams
they belong to) that will be set on every record if the user does not
explicitly set it.

Unlike the teams module in SugarCRM PRO the assigned user always have access
to a record even if it that user does not belong to the assigned team.
Also if the assigned team is empty all users have access.

2008-12-24:
1) Now limiting ListViews as well.
2) A new action "Repair Teams" have been added to the module menu.
   It will run automatically after installation to create
   and populate the team "Everyone" and to check and repair all "reports_to"
   team memberships. You need to run it manually whenever you add users or
   your reporting structure changes.
3) Added checks to prevent normal users from editing teams or team members.

2009-01-08:
1) Changed admin menu to work on 5.2
2) Added member/manager and reports_to to the subpanel
3) Fixed bug when adding the same user to a team more than once
4) Automated adding of managers when a user is added - should mean a lot less use of RepairTeams

2009-01-09:
1) Limit popup listviews

2009-01-18:
1) "Enable Modules" action that create the vardefs for selected modules to have "real"
   team_id and team_name fields instead of custom fields.
2) Improved checks to prevent normal users from editing teams or team members.

2009-02-04
1) Add default teams to users and "Set Default Teams" action to teams module
2) Allow multiselect when adding users to a team - courtesy of SugarDev.net

2013-05-09
1) Add 6.x.x compatibility to manifest.php file

Known limitations:
1) Compatibility with databases other than MySQL has not been tested - particulary RepairTeams

TODO:
1) Limit dashlet listviews


Marnus van Niekerk
2009/02/04
sugarcrm@mjvn.net

--

Prior to 0.97 you needed to add a custom relate field called team or team_name
that relates to Teams to any module you wanted to team enable.
Studio will rename the field "team_c" or "team_name_c" and create
the related id field as "team_id_c".
For compatibility with previous versions the custom logic will still check for
and act on custom team_c or team_name_c fields.
