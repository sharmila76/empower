<?PHP
$mod_strings['LBL_TEAMS_ADMIN'] = 'Teams';
$mod_strings['LBL_TEAMS_ADMIN_DESCRIPTION'] = 'Manage user team memberships';
$mod_strings['LBL_TEAMS_ADMIN_TITLE'] = 'Teams';
$mod_strings['TEAMS_ADMIN_TITLE'] = 'Teams';
$mod_strings['TEAMS_ADMIN_DESC'] = 'Create and manage teams.';
?>
