<?php
$layout_defs["Users"]["subpanel_setup"]["team_memberships"] = array (
  'order' => 100,
  'module' => 'team',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_TEAM_MEMBERSHIPS_FROM_TEAM_TEAM_TITLE',
  'get_subpanel_data' => 'team_memberships',
);
?>
