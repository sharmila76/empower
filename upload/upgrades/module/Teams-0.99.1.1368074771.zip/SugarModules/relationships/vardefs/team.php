<?php
$dictionary["team"]["fields"]["team_memberships"] = array (
  'name' => 'team_memberships',
  'type' => 'link',
  'relationship' => 'team_memberships',
  'source' => 'non-db',
);
?>
