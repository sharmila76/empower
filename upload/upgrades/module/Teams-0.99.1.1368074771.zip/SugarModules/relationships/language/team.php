<?php
$mod_strings [ "LBL_TEAM_MEMBERSHIPS_FROM_USERS_TITLE" ] = "Users" ;
