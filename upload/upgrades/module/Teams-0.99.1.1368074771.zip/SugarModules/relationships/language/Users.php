<?php
$mod_strings [ "LBL_TEAM_MEMBERSHIPS_FROM_TEAM_TEAM_TITLE" ] = "team" ;
