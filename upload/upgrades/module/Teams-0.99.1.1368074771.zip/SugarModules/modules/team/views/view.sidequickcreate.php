<?php
class ViewSidequickcreate extends SugarView{
	
	function ViewSidequickcreate(){
		parent::SugarView();
	}
	
	function preDisplay(){
	}

	function display(){
		return '';
	}
}

?>
