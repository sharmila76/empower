<?php
	sugar_die("Unauthorized access to administration.");
?>
