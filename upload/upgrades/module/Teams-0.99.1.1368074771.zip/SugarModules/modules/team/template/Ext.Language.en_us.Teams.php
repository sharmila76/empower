<?php
$mod_strings [ "LBL_TEAM_ID" ] = "Assigned Team" ;
$mod_strings [ "LBL_TEAM_NAME" ] = "Assigned Team" ;
$mod_strings [ "LBL_TEAM" ] = "Visible To" ;
