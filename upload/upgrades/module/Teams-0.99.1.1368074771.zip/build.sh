:

export TZ=GMT
ts=`date +%s`
date=`date "+%Y-%m-%d %H:%M:00"`
version=`cat version.txt`.$ts

[ -f manifest.php ] || exit

file=`pwd`
file=`basename $file`-$version.zip

echo $file $ts $date
#fgrep \'version manifest.php | cut -f2 -d\>

sed -i "s/published_date' => .*$/published_date' => '$date',/" manifest.php
sed -i "s/Marnus'/Marnus van Niekerk'/" manifest.php
sed -i "s/version' => .*$/version' => '$version',/" manifest.php

rm -f /tmp/$file
zip -r /tmp/$file * >/dev/null 2>&1
