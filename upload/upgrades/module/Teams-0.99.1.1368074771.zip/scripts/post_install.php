<?php
function post_install()
{
	// post_install is also called on uninstall
	if (file_exists("modules/team/RepairTeams.php"))
		require "modules/team/RepairTeams.php";
}
?>
