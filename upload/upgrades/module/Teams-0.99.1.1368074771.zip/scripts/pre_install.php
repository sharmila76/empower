<?php
function pre_install()
{
	require_once('include/utils.php');

	// Hook to cache current user's teams
	check_logic_hook_file("Users", "after_retrieve",
		array(1, 'Teams CE Users Extension', 'modules/team/teams_logic.php',
                                'teams_logic', 'get_user_teams'));

	// Hook to add logic to limit listviews to modules listviewdefs.php
	check_logic_hook_file("Users", "after_retrieve",
		array(2, 'Teams CE ListView Extension', 'modules/team/teams_logic.php',
                                'teams_logic', 'add_list_logic_hook'));

	// Hook to fill in member/manager on subpanel
	check_logic_hook_file("Users", "process_record",
		array(1, 'Teams CE Subpanel Extension', 'modules/team/teams_logic.php',
				'teams_logic', 'get_subpanel_user_type'));

	// Hook to check access if module has a team[_name]_c column
	check_logic_hook_file("", "after_retrieve",
		array(1, 'Teams CE Extension', 'modules/team/teams_logic.php',
                                'teams_logic', 'check_team_access'));

	// Hook to fill in defaul team on beans if left empty
	check_logic_hook_file("", "before_save",
		array(1, 'Teams CE Extension', 'modules/team/teams_logic.php',
				'teams_logic', 'set_default_team_bean'));
}
?>
