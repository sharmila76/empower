<?php
function post_install ()
{
    replace();
    showMessage();
 

}
function showMessage(){
echo "==message==
Please add to your website the following javascript code:<br>
<code>&lt;script type='text/javascript' src='".curPageURL()."/sugarportal.js'&gt;&lt;script&gt;</code>
==message==";
}
function replace(){
  $content='document.write("<iframe frameborder=\'0\' width=\'720\' height=\'500\' src=\''.curPageURL().'/iportal.php\'></iframe>");';
  
  $f=file_put_contents("sugarportal.js", $content);
}

function curPageURL() {
    global $sugar_config;
    if(file_exists('config.php')) include_once('config.php');
    if(file_exists('config_override.php')) include_once('config_override.php');

    $pageURL=$sugar_config['site_url'];
    return $pageURL;
}
?>