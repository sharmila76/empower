<?php
$mod_strings['LBL_SHOW_IN_PORTAL'] = 'Show in Portal';
$mod_strings['LBL_BUGS_SUBPANEL_TITLE'] = 'Bugs';
$mod_strings['LBL_CONTACT_C'] = 'Contact';
?>
