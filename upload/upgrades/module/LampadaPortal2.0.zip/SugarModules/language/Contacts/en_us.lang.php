<?php
$mod_strings['LNK_CONTACTS_CREATE_IPORTAL_USER'] = "Create Portal User";
$mod_strings['LNK_CONTACTS_CREATE_IPORTAL_USER_THIS'] = "Create Portal User for Current Contact";
$mod_strings['LBL_SHOW_IN_PORTAL'] = "Show  in Portal";
$mod_strings['LBL_CONTACTS_LG_PORTALUSER_FROM_LG_PORTALUSER_TITLE'] = 'Portal User';
?>