<?php
$mod_strings['LNK_CONTACTS_CREATE_IPORTAL_USER'] = "Criar Usuário do Portal";
$mod_strings['LNK_CONTACTS_CREATE_IPORTAL_USER_THIS'] = "Criar Usuário do Portal para o Contato Atual";
$mod_strings['LBL_SHOW_IN_PORTAL'] = "Show  in Portal";
$mod_strings['LBL_CONTACTS_LG_PORTALUSER_FROM_LG_PORTALUSER_TITLE'] = 'Portal User';
?>