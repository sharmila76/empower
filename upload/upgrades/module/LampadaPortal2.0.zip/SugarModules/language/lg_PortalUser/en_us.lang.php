<?php
$mod_strings['LBL_CONTACTS_LG_PORTALUSER_FROM_CONTACTS_TITLE'] = 'Contacts';
?>
