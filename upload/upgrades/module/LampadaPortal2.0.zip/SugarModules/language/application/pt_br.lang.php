<?php

$app_list_strings['moduleList']['lg_PortalUser'] = 'Usuários do Portal';
$app_list_strings['portaluser_status']['active'] = 'Ativo';
$app_list_strings['portaluser_status']['inactive'] = 'Inativo';
$app_list_strings['role_list'][''] = '';
$app_strings['ERR_NO_PERMISSION'] = "Você não possui acesso ao Portal";
$app_strings['LBL_CHANGE_PASSWORD'] = 'Mudar senha';