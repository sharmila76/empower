<?php
 // created: 2010-11-16 08:00:04
$dictionary['Note']['fields']['show_in_portal_c']['enforced']='false';

 ?>