<?php
//auto-generated file DO NOT EDIT
$layout_defs['Cases']['subpanel_setup']['bugs']['override_subpanel_name'] = 'Casedefault';
?>