<?php
// created: 2010-03-29 15:00:53
$mod_strings = array (
  'LBL_CONTACT_C' => 'Contact',
);
?>
