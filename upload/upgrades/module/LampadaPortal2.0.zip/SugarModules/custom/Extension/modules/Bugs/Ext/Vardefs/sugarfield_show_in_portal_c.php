<?php
 // created: 2010-11-16 07:52:37
$dictionary['Bug']['fields']['show_in_portal_c']['enforced']='false';

 ?>