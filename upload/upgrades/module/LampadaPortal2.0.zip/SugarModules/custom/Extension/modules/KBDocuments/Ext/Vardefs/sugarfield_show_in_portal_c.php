<?php
 // created: 2010-11-16 08:04:01
$dictionary['KBDocument']['fields']['show_in_portal_c']['enforced']='false';

 ?>