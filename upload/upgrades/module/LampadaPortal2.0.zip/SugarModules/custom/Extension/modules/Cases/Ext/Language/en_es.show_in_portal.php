<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$mod_strings = array (
  'LBL_SHOW_IN_PORTAL' => 'Show in Portal',
);
?>
