<?php
 // created: 2010-11-02 13:06:02
$dictionary['Case']['fields']['show_in_portal_c']['enforced']='false';

 ?>