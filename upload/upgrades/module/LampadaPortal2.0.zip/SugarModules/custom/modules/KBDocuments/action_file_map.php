<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$action_file_map['save2'] = 'custom/modules/KBDocuments/Save.php';
?>
