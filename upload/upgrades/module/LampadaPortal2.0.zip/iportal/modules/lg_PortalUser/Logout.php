<?php
	AuthenticationController::getInstance()->logout();