<?php
require_once('iportal/include/MVC/View/IportalView.php');

class lg_PortalUserViewChangePassword extends IportalView {
	
	function preDisplay() {
		//var_dump($this);
	}
}