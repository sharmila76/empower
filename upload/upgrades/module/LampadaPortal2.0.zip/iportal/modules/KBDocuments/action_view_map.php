<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$action_view_map['editview']= 'editprueba';
?>
