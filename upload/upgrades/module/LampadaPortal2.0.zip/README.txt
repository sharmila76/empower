Hi !

Thank you for downloading the Lampada Portal 2.0 for your SugarCRM system. 
All of us at Lampada Global wish you the best of luck with it. If you like 
it or need help with it, please feel free to contact us via Skype (dtokeefe) 
or email (equipe@lampadaglobal.com).

What does it do?
Lampada Portal allows your Contacts to login to a separate (but similar) 
interface of your SugarCRM system. There, they can access Cases, Bugs, Notes,
Contacts, Accounts and KnowledgeBase Documents.

Can I extend it?
Yes, you can extend it, according to the Affero license.

How does it work?
You create a PortalUser record for each Contact that will have access to the 
Portal. PortalUsers must be assigned a Role. Roles determine the Contacts
access to modules in the portal.

Does it require a Sugar license?
Yes. For Pro and Enterprise systems, one licensed user must be used as the 
Portal User, to give authentication context to the Contacts who login to the 
Portal. The Portal User must be included in each Role used to control access
to the Portal.

Where do the Contacts login?
http://yoursugarsystem/iportal.php

Are there any gotchas?
Not really, but testing is easiest with the 2 different browsers (e.g. IE 
and Chrome). One for the Sugar side and the other for the Portal side. This
keeps the sessions separate. Also, CE users will need to remove the references
KnowledgeBase in the manifest and other locations.

Enjoy !

David O'Keefe

 


