<?php

	function get_validate_record_js()
	{

	}

	function get_new_record_form()
	{

	}

	


?>

