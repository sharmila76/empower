<?php
	$layout_defs['Inventory_items']['subpanel_setup']['inventory_changes'] = array(
		'order' => 9,
		'module' => 'Inventory_changes',
		'subpanel_name' => 'forInventory_items',
		'get_subpanel_data' => 'inventory_changes',
		'add_subpanel_data' => 'inventory_item_id',
		'title_key' => 'LBL_INVENTORY_CHANGES_SUBPANEL_TITLE',
		'top_buttons' => array()
		);
?>
