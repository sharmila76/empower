<?php
$dictionary['Project']['fields']['timesheet'] = array(
  'name' => 'timesheet',
  'type' => 'link',
  'relationship' => 'project_timesheet',
  'source'=>'non-db'
);
?>