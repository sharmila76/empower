<?php
$dictionary['ProjectTask']['fields']['timesheet'] = array(
  'name' => 'timesheet',
  'type' => 'link',
  'relationship' => 'projecttask_timesheet',
  'source'=>'non-db'
);
?>