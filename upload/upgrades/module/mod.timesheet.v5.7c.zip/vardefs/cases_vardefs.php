<?php
$dictionary['Case']['fields']['timesheet'] = array(
  'name' => 'timesheet',
  'type' => 'link',
  'relationship' => 'cases_timesheet',
  'source'=>'non-db'
);
?>