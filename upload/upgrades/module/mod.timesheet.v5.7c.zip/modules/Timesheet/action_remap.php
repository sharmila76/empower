<?php
/**
 * 
 * Here you can setup default page to be loaded
 * when user clicks on Timesheet tab
 *
 * Possible values:
 * EditMatrix
 * EditDailyMatrix
 * EditView
 * index
 */
$action_remap['index'] = 'EditMatrix';