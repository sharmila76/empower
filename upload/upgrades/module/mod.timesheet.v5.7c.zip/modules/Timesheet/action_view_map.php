<?php
$action_view_map['editmatrix']= 'editmatrix';
$action_view_map['editdailymatrix'] = 'editdailymatrix';
$action_view_map['settings'] = 'settings';