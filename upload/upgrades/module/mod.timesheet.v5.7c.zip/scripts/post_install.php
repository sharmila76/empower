<?php
if(!defined('sugarEntry'))define('sugarEntry', true);
require_once('include/utils.php');

function post_install() {
  $uninstall = isset($GLOBALS['mi_remove_tables']);
  if ($uninstall) {
    return;
  }

  require_once ('modules/DynamicFields/FieldCases.php');
  require_once ('modules/DynamicFields/DynamicField.php');
  require_once ('modules/ModuleBuilder/parsers/ParserFactory.php');

  $custom_fields = array();

  $custom_fields['Cases'][] = array (
    'name' => 'budget',
    'label' => 'LBL_BUDGET',
    'label_value' => 'Budget',
    'module' => 'Cases',
    'audited' => 1
  );

  $custom_fields['Project'][] = array (
    'name' => 'budget',
    'label' => 'LBL_BUDGET',
    'label_value' => 'Budget',
    'module' => 'Project',
    'audited' => 1
  );

  $custom_fields['ProjectTask'][] = array (
    'name' => 'budget',
    'label' => 'LBL_BUDGET',
    'label_value' => 'Budget',
    'module' => 'ProjectTask',
    'audited' => 1
  );

  $custom_fields['Cases'][] = array (
    'name' => 'actual',
    'label' => 'LBL_ACTUAL',
    'label_value' => 'Total Actual Effort (hrs)',
    'module' => 'Cases',
    'audited' => 0
  );

  $custom_fields['Project'][] = array (
    'name' => 'actual',
    'label' => 'LBL_ACTUAL',
    'label_value' => 'Total Actual Effort (hrs)',
    'module' => 'Project',
    'audited' => 0
  );

  $custom_fields['ProjectTask'][] = array (
    'name' => 'actual',
    'label' => 'LBL_ACTUAL',
    'label_value' => 'Total Actual Effort (hrs)',
    'module' => 'ProjectTask',
    'audited' => 0
  );

  $custom_fields['Cases'][] = array (
    'name' => 'billable',
    'label' => 'LBL_BILLABLE',
    'label_value' => 'Total Billable Effort (hrs)',
    'module' => 'Cases',
    'audited' => 0
  );

  $custom_fields['Project'][] = array (
    'name' => 'billable',
    'label' => 'LBL_BILLABLE',
    'label_value' => 'Total Billable Effort (hrs)',
    'module' => 'Project',
    'audited' => 0
  );

  $custom_fields['ProjectTask'][] = array (
    'name' => 'billable',
    'label' => 'LBL_BILLABLE',
    'label_value' => 'Total Billable Effort (hrs)',
    'module' => 'ProjectTask',
    'audited' => 0
  );

  foreach ($custom_fields as $_module => $cstm_field) {
    // test whether custom fields are already installed
    $query = "SELECT COUNT(*) FROM fields_meta_data WHERE id = '".$_module."budget_c'";
    $hasCustom = false;
    if ($GLOBALS['db']->getOne($query) > 0) {
      $hasCustom = true;
    }
    if (!$hasCustom) {
      foreach ($cstm_field as $cstm) {
        $field = get_widget('float');
        $field->name = $cstm['name'];
        $field->vname = $field->label = $cstm['label'];
        $field->dubplicate_merge = 0;
        $field->audited = $cstm['audited'];
        $field->len = 18;
        $field->ext1 = 2;

        $module = $cstm['module'];
        $df = new DynamicField($module);
        $class_name = $GLOBALS ['beanList'] [$module];
        require_once ($GLOBALS ['beanFiles'] [$class_name]);
        // Due to Module Loader Restrictions
        // http://developers.sugarcrm.com/wordpress/2009/08/14/module-loader-restrictions/
        // http://kb.sugarcrm.com/custom/module-loader-restrictions-for-sugar-open-cloud/
        switch ($class_name) {
          case 'Project':
            $mod = new Project;
          break;

          case 'ProjectTask':
            $mod = new ProjectTask;
          break;

          case 'aCase':
            $mod = new aCase;
          break;
        }
        $df->setup($mod);
        $field->save($df);
        $params ["label_" . $cstm['label']] = $cstm['label_value'];
        $parser = ParserFactory::getParser('label', $module);
        $parser->handleSave($params, 'en_us');
      }
    }
  }
}

?>