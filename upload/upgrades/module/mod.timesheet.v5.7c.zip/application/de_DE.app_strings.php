<?php
$app_list_strings['moduleList']['Timesheet'] = 'Timesheet';

$app_list_strings['timesheet_status_dom']= array (
'Booked' => 'erfasst',
'Checked' => 'geprüft',
'Invoiced' => 'abgerechnet',
);

$app_list_strings['record_type_display_timesheet'] = array (
'Cases' => 'Fall',
'Project' => 'Projekt',
'ProjectTask' => 'Projektaufgabe',
);
?>