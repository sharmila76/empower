<?php
$layout_defs['Cases']['subpanel_setup']['timesheet'] =  array(
  'order' => 2,
  'module' => 'Timesheet',
  'get_subpanel_data' => 'timesheet',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_TIMESHEET_SUBPANEL_TITLE',
); 
?>