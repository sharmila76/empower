<?php
$mod_strings['LBL_TIMESHEET_SUBPANEL_TITLE'] = 'Zeiteinträge';