<?php
$searchdefs ['OSS_TeamMember'] = 
array (
  'templateMeta' => 
  array (
    'maxColumns' => '1',
    'widths' => 
    array (
      'label' => '10',
      'field' => '30',
    ),
  ),
  'layout' => 
  array (
    'basic_search' => 
    array (
      0 => 'name',
    ),
    'advanced_search' => 
    array (
      0 => 'name',
    ),
  ),
);
?>
