<?php 
//WARNING: The contents of this file are auto-generated
$mod_strings ['LBL_NAME' ]= 'Recruitment Agency name';
$mod_strings ['LBL_PHONE' ]= 'Phone Office';
$mod_strings ['LBL_MOBILE' ]= 'Mobile';
$mod_strings ['LBL_OTHERPHONE' ]= 'Other Phone';
$mod_strings ['LBL_AGENCY_CONTACT_PERSON' ]= 'Agency contact person';
$mod_strings ['LBL_ADDRESS_CITY' ]= ' City';
$mod_strings ['LBL_ADDRESS_STATE' ]= ' State';
$mod_strings ['LBL_ADDRESS_POSTALCODE' ]= ' PostalCode';
$mod_strings ['LBL_ADDRESS_COUNTRY' ]= ' Country';
$mod_strings ['LBL_ADDRESS' ]= 'Address';
$mod_strings ['LBL_WEBSITE' ]= 'Website';
$mod_strings ['LBL_EMAIL' ]= 'Email';
$mod_strings ['LBL_PANEL1' ]= 'Address Information';
?>