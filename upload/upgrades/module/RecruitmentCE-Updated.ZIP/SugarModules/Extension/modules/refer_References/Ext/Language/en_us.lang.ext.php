<?php 
//WARNING: The contents of this file are auto-generated


$mod_strings [ "LBL_REFER_REFERENCES_GAUR_CANDIDATES_FROM_GAUR_CANDIDATES_TITLE" ] = "Candidates" ;


$mod_strings ['VALUE' ]= 'Comments';
$mod_strings [ 'LBL_PHONE' ]= 'Phone';
$mod_strings ['LBL_DESIGNATION' ]= 'Designation';
$mod_strings ['LBL_EMAIL' ]= 'Email';
$mod_strings [ 'LBL_COMPANY' ]= 'Company';
$mod_strings ['LBL_TITLE' ]= 'Title';
$mod_strings ['LBL_REFERENCECHECKEDBY' ]= 'Reference Checked By';
$mod_strings ['LBL_DESCRIPTION' ]= 'Comments';
$mod_strings ['DESIGNATION_C' ]= 'Designation';
$mod_strings [ 'LBL_PANEL1' ]= 'Reference Check Report';
$mod_strings ['LBL_ASSIGNED_TO_NAME' ]= 'Reference Checked By';
?>