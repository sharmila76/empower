<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2010-02-27 02:18:35
$dictionary["refer_References"]["fields"]["refer_references_gaur_candidates"] = array (
  'name' => 'refer_references_gaur_candidates',
  'type' => 'link',
  'relationship' => 'refer_references_gaur_candidates',
  'source' => 'non-db',
);


?>