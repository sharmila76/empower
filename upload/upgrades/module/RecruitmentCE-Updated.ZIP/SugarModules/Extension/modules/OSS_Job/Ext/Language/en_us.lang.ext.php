<?php 
//WARNING: The contents of this file are auto-generated


$mod_strings [ "LBL_GAUR_CANDIDATES_OSS_JOB_FROM_GAUR_CANDIDATES_TITLE" ] = "Candidates" ;

$mod_strings ['LBL_DESCRIPTION'] = 'Job Description';
$mod_strings ['LBL_NO_OFVACANCIES'] = 'No. of Vacancies';
$mod_strings ['LBL_TARGETDATETOHIRE'] = 'Target Date to Hire';
$mod_strings ['LBL_PROJECT'] = 'Project';
$mod_strings ['LBL_CLIENT'] = 'Client';
$mod_strings ['LBL_TEAM'] = 'Team';
$mod_strings ['LBL_PROJECTTEAM'] = 'Project Team';
$mod_strings ['LBL_TEAM '] = 'Team ';
$mod_strings ['LBL_GAUR_CANDIDATES_OSS_JOB_SUBPANEL_TITLE'] = 'CANDIDATES';
$mod_strings ['LBL_NOOFCANDIDATE_C'] = 'No. Of Candidates';

?>