<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2010-03-02 03:40:55
$layout_defs["OSS_Job"]["subpanel_setup"]["gaur_candidates_oss_job"] = array (
  'order' => 100,
  'module' => 'gaur_Candidates',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GAUR_CANDIDATES_OSS_JOB_FROM_GAUR_CANDIDATES_TITLE',
  'get_subpanel_data' => 'gaur_candidates_oss_job',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'People',
      'mode' => 'MultiSelect',
    ),
  ),
);



//auto-generated file DO NOT EDIT
$layout_defs['OSS_Job']['subpanel_setup']['gaur_candidates_oss_job']['override_subpanel_name'] = 'OSS_Jobdefault';

?>