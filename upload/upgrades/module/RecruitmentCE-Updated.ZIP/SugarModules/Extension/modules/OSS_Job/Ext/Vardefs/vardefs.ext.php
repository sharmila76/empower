<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2010-03-02 03:40:55
$dictionary["OSS_Job"]["fields"]["gaur_candidates_oss_job"] = array (
  'name' => 'gaur_candidates_oss_job',
  'type' => 'link',
  'relationship' => 'gaur_candidates_oss_job',
  'source' => 'non-db',
);


?>