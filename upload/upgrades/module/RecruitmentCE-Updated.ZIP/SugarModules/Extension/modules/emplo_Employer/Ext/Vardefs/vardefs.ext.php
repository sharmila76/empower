<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2010-02-25 07:29:07
$dictionary["emplo_Employer"]["fields"]["emplo_employer_gaur_candidates"] = array (
  'name' => 'emplo_employer_gaur_candidates',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
);


?>