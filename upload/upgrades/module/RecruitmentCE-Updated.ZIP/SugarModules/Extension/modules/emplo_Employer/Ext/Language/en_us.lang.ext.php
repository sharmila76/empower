<?php 
 //WARNING: The contents of this file are auto-generated


$mod_strings [ "LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_GAUR_CANDIDATES_TITLE" ] = "Candidates" ;

$mod_strings [ "LBL_NOOFEMPLOYEES" ] = "No of Employees" ;

$mod_strings [ "LBL_NOOFCANDIDATES_C" ] = "Candidates #" ;
?>