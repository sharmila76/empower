<?php 
 //WARNING: The contents of this file are auto-generated


$mod_strings [ "LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE" ] = "Employer" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_CALLS_FROM_CALLS_TITLE" ] = "Calls" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE" ] = "Meetings" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_NOTES_FROM_NOTES_TITLE" ] = "Notes" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_TASKS_FROM_TASKS_TITLE" ] = "Tasks" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE" ] = "Emails" ;
$mod_strings [ "LBL_REFER_REFERENCES_GAUR_CANDIDATES_FROM_REFER_REFERENCES_TITLE" ] = "References" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_EVAL_EVALUATIONS_FROM_EVAL_EVALUATIONS_TITLE" ] = "Evaluations" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_OSS_JOB_FROM_OSS_JOB_TITLE" ] = "Job" ;


$mod_strings [ "LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE" ] = "Employer" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_CALLS_FROM_CALLS_TITLE" ] = "Calls" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE" ] = "Meetings" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_NOTES_FROM_NOTES_TITLE" ] = "Notes" ;


$mod_strings [ "LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE" ] = "Employer" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_CALLS_FROM_CALLS_TITLE" ] = "Calls" ;


$mod_strings [ "LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE" ] = "Employer" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_CALLS_FROM_CALLS_TITLE" ] = "Calls" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE" ] = "Meetings" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_NOTES_FROM_NOTES_TITLE" ] = "Notes" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_TASKS_FROM_TASKS_TITLE" ] = "Tasks" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE" ] = "Emails" ;
$mod_strings [ "LBL_REFER_REFERENCES_GAUR_CANDIDATES_FROM_REFER_REFERENCES_TITLE" ] = "References" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_EVAL_EVALUATIONS_FROM_EVAL_EVALUATIONS_TITLE" ] = "Evaluations" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_OSS_JOB_FROM_OSS_JOB_TITLE" ] = "Job" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_REFER_REFERRALS_FROM_REFER_REFERRALS_TITLE" ] = "Referrals" ;


$mod_strings [ "LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE" ] = "Employer" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_CALLS_FROM_CALLS_TITLE" ] = "Calls" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE" ] = "Meetings" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_NOTES_FROM_NOTES_TITLE" ] = "Notes" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_TASKS_FROM_TASKS_TITLE" ] = "Tasks" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE" ] = "Emails" ;
$mod_strings [ "LBL_REFER_REFERENCES_GAUR_CANDIDATES_FROM_REFER_REFERENCES_TITLE" ] = "References" ;


$mod_strings [ "LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE" ] = "Employer" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_CALLS_FROM_CALLS_TITLE" ] = "Calls" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE" ] = "Meetings" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_NOTES_FROM_NOTES_TITLE" ] = "Notes" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_TASKS_FROM_TASKS_TITLE" ] = "Tasks" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE" ] = "Emails" ;


$mod_strings [ "LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE" ] = "Employer" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_CALLS_FROM_CALLS_TITLE" ] = "Calls" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE" ] = "Meetings" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_NOTES_FROM_NOTES_TITLE" ] = "Notes" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_TASKS_FROM_TASKS_TITLE" ] = "Tasks" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE" ] = "Emails" ;
$mod_strings [ "LBL_REFER_REFERENCES_GAUR_CANDIDATES_FROM_REFER_REFERENCES_TITLE" ] = "References" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_EVAL_EVALUATIONS_FROM_EVAL_EVALUATIONS_TITLE" ] = "Evaluations" ;


$mod_strings [ "LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE" ] = "Employer" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_CALLS_FROM_CALLS_TITLE" ] = "Calls" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE" ] = "Meetings" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_NOTES_FROM_NOTES_TITLE" ] = "Notes" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_TASKS_FROM_TASKS_TITLE" ] = "Tasks" ;


$mod_strings [ "LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE" ] = "Employer" ;


$mod_strings [ "LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE" ] = "Employer" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_CALLS_FROM_CALLS_TITLE" ] = "Calls" ;
$mod_strings [ "LBL_GAUR_CANDIDATES_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE" ] = "Meetings" ;


$mod_strings ['LBL_DESCRIPTION' ]= 'Key Skills ' ;
  $mod_strings ['LBL_LAST_NAME' ]= 'Name of the Candidate' ;
  $mod_strings ['LBL_MOBILE_PHONE' ]= 'Mobile No.' ;
  $mod_strings ['LBL_PRIMARY_ADDRESS_STREET' ]= 'Postal Address' ;
  $mod_strings ['LBL_TITLE' ]= 'Resume Title' ;
  $mod_strings ['LBL_WORK_PHONE' ]= 'Telephone No.' ;
  $mod_strings ['VALUE' ]= 'Skills Description' ;
  $mod_strings ['LBL_RESUMEID' ]= 'Resume ID' ;
  $mod_strings ['LBL_DATEOFBIRTH' ]= 'Date of Birth' ;
  $mod_strings ['LBL_WORKEXPERIENCEYEARS' ]= 'Work Experience ' ;
  $mod_strings ['LBL_WORKEXPERIENCEMONTHS' ]= 'Work Experience Months' ;
  $mod_strings ['LBL_FUNCTIONALAREA' ]= 'Functional Area' ;
  $mod_strings ['LBL_CURRENTLOCATION' ]= 'Current Location' ;
  $mod_strings ['LBL_PREFERREDLOCATION' ]= 'Preferred Location' ;
  $mod_strings ['LBL_CURRENTEMPLOYER' ]= 'C2212urrent Employer' ;
  $mod_strings ['LBL_CURRENTDESIGNATION' ]= 'Current Designation' ;
  $mod_strings ['LBL_ANNUALSALARY' ]= 'Annual Salary' ;
  $mod_strings ['LBL_UGCOURSE' ]= 'U.G. Course ' ;
  $mod_strings ['LBL_UGSPECIALIZATION' ]= 'U. G. Specialisation' ;
  $mod_strings ['LBL_UGINSTITUTE' ]= 'U. G. Institute ' ;
  $mod_strings ['LBL_PGCOURSE' ]= 'P. G. Course ' ;
  $mod_strings ['LBL_PGSPECIALIZATION' ]= 'P. G. Specialisation' ;
  $mod_strings ['LBL_PGINSTITUTE' ]= 'P. G. Institute ' ;
  $mod_strings ['LBL_POSTPGCOURSE' ]= ' Post P. G. Course' ;
  $mod_strings ['LBL_POSTPGSPECIALIZATION' ]= 'Post P. G. Specialisation' ;
  $mod_strings ['LBL_POSTPGINSITUTE' ]= 'Post P. G. Institute ' ;
  $mod_strings ['LBL_LASTMODIFIEDDATE' ]= 'Last Modified Date' ;
  $mod_strings ['LBL_LASTACTIVEDATE' ]= 'Date Of Birth:' ;
  $mod_strings ['LBL_OFFICE_PHONE' ]= 'Telephone No.' ;
  $mod_strings ['LBL_ADDRESS_INFORMATION' ]= 'Work Experience' ;
  $mod_strings ['LBL_PRIMARY_ADDRESS' ]= 'Postal Address' ;
  $mod_strings ['LBL_PANEL1' ]= 'Skill Set (Years of experience)' ;
  $mod_strings ['LBL_EMAIL_ADDRESS' ]= 'Email' ;
  $mod_strings ['LBL_ANY_EMAIL' ]= 'Any Email' ;
  $mod_strings ['LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE' ]= 'Current Employer' ;
  $mod_strings ['LBL_PHP4' ]= 'PHP4' ;
  $mod_strings ['LBL_PHP5' ]= 'PHP5' ;
  $mod_strings ['LBL_MYSQL' ]= 'MySQL' ;
  $mod_strings ['LBL_DRUPAL' ]= 'Drupal' ;
  $mod_strings ['LBL_XCART' ]= 'Xcart' ;
  $mod_strings ['LBL_SUGARCRM' ]= 'SugarCRM' ;
  $mod_strings ['LBL_LINUX' ]= 'LINUX' ;
  $mod_strings ['LBL_ZENDFRAMEWORK' ]= 'Zend Framework' ;
  $mod_strings ['LBL_SYMFONYFRAMEWORK' ]= 'Symfony Framework' ;
  $mod_strings ['LBL_CAKEPHP' ]= 'CakePHP' ;
  $mod_strings ['LBL_JAVASCRIPT' ]= 'Javascript' ;
  $mod_strings ['LBL_JAVA' ]= 'Java' ;
  $mod_strings ['LBL_CPROGRAMMING' ]= 'C:' ;
  $mod_strings ['LBL_OOPS' ]= 'OOPS' ;
  $mod_strings ['LBL_JOOMLA' ]= 'Joomla' ;
  $mod_strings ['LBL_CSS' ]= 'CSS' ;
  $mod_strings ['LBL_PANEL2' ]= 'Salary' ;
  $mod_strings ['LBL_KEYSKILLS' ]= 'Skills Description ' ;
  $mod_strings ['LBL_SKILLDESCRIPTION' ]= 'Skills Description' ;
  $mod_strings ['LBL_CURRENTCTC' ]= 'Current CTC' ;
  $mod_strings ['LBL_EXPECTEDCTC' ]= 'Expected CTC' ;
  $mod_strings ['LBL_OFFEREDCTC' ]= 'Offered CTC' ;
  $mod_strings ['LBL_FINALCTC' ]= 'Final CTC' ;
  $mod_strings ['LBL_COMMENT' ]= 'Comment' ;
  $mod_strings ['LBL_JOININGDATE' ]= 'Joining Date' ;
  $mod_strings ['LBL_PANEL3' ]= 'Office Use' ;
  $mod_strings ['LBL_PANEL4' ]= 'Work Experience' ;
  $mod_strings ['LBL_OFFICESTATUS' ]= 'Status' ;
  $mod_strings ['LBL_REASONFORREJECTION' ]= 'Reason for Rejection' ;
  $mod_strings ['LBL_JOB' ]= 'Job Opening' ;
  $mod_strings ['LBL_REFERRED' ]= 'Referred By OSSCube Employee' ;
  $mod_strings ['LBL_OSSCUBEEMPLOYEEREFERER' ]= 'OSSCube Employee (Referer)' ;
  $mod_strings ['LBL_REFERREDBY' ]= 'Referred By' ;
  $mod_strings ['LBL_RECRUITMENTAGENCY' ]= 'Recruitment Agency' ;
  $mod_strings ['LBL_ANYOTHER' ]= 'Any Other' ;
  $mod_strings ['LBL_GAUR_CANDIDATES_EVAL_EVALUATIONS_SUBPANEL_TITLE' ]= 'EVALUATIONS' ;
  $mod_strings ['LBL_GAUR_CANDIDATES_OSS_JOB_SUBPANEL_TITLE' ]= 'Job Opening' ;
  $mod_strings ['LBL_GAUR_CANDIDATES_REFER_REFERRALS_SUBPANEL_TITLE' ]= 'CANDIDATES_REFERRALS' ;
  $mod_strings ['LBL_REFER_REFERENCES_GAUR_CANDIDATES_SUBPANEL_TITLE' ]= 'REFERENCES_CANDIDATES' ;
  $mod_strings ['LBL_DATEOFBIRTHTEXTFIELD'] = 'LBL_Dateofbirthtextfield' ;
  $mod_strings ['LBL_DATE_ENTERED' ]= 'Date Created(S)' ;
  $mod_strings ['LBL_DATE_MODIFIED' ]= 'Date Modified(S)' ;
  $mod_strings ['DATE OF BIRTH'] = 'Date Of Birth' ;

?>