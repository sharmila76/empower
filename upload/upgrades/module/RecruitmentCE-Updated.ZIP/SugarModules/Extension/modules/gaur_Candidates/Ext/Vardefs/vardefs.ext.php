<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates"] = array (
  'name' => 'emplo_employer_gaur_candidates',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates_name"] = array (
  'name' => 'emplo_employer_gaur_candidates_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE',
  'save' => true,
  'id_name' => 'emplo_emplf893mployer_ida',
  'link' => 'emplo_employer_gaur_candidates',
  'table' => 'emplo_employer',
  'module' => 'emplo_Employer',
  'rname' => 'name',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_emplf893mployer_ida"] = array (
  'name' => 'emplo_emplf893mployer_ida',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:30:17
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_calls"] = array (
  'name' => 'gaur_candidates_activities_calls',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_calls',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:18
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_meetings"] = array (
  'name' => 'gaur_candidates_activities_meetings',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_meetings',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:19
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_notes"] = array (
  'name' => 'gaur_candidates_activities_notes',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_notes',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:19
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_tasks"] = array (
  'name' => 'gaur_candidates_activities_tasks',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_tasks',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:20
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_emails"] = array (
  'name' => 'gaur_candidates_activities_emails',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_emails',
  'source' => 'non-db',
);


// created: 2010-02-27 02:18:35
$dictionary["gaur_Candidates"]["fields"]["refer_references_gaur_candidates"] = array (
  'name' => 'refer_references_gaur_candidates',
  'type' => 'link',
  'relationship' => 'refer_references_gaur_candidates',
  'source' => 'non-db',
);


// created: 2010-03-02 03:40:29
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_eval_evaluations"] = array (
  'name' => 'gaur_candidates_eval_evaluations',
  'type' => 'link',
  'relationship' => 'gaur_candidates_eval_evaluations',
  'source' => 'non-db',
);



// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["job_c"] = array (
      'required' => '0',
      'source' => 'non-db',
      'name' => 'job_c',
      'vname' => 'LBL_JOB',
      'type' => 'relate',
      'massupdate' => '1',
      'default' => NULL,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'enabled',
      'duplicate_merge_dom_value' => '1',
      'audited' => 1,
      'reportable' => 1,
      'len' => '255',
      'id_name' => 'oss_job_id_c',
      'ext2' => 'OSS_Job',
      'module' => 'OSS_Job',
      'rname' => 'name',
      'quicksearch' => 'enabled',
      'studio' => 'visible',
      'id' => 'gaur_Candidatesjob_c',
      'custom_module' => 'gaur_Candidates',
);

$dictionary["gaur_Candidates"]["fields"]["oss_job_id_c"] = array (
      'required' => '0',
      'source' => 'custom_fields',
      'name' => 'oss_job_id_c',
      'vname' => 'LBL_LIST_RELATED_TO',
      'type' => 'id',
      'massupdate' => '1',
      'default' => NULL,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => 0,
      'reportable' => 0,
      'len' => '36',
      'id' => 'gaur_Candidatesoss_job_id_c',
      'custom_module' => 'gaur_Candidates',
);



// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates"] = array (
  'name' => 'emplo_employer_gaur_candidates',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates_name"] = array (
  'name' => 'emplo_employer_gaur_candidates_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE',
  'save' => true,
  'id_name' => 'emplo_emplf893mployer_ida',
  'link' => 'emplo_employer_gaur_candidates',
  'table' => 'emplo_employer',
  'module' => 'emplo_Employer',
  'rname' => 'name',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_emplf893mployer_ida"] = array (
  'name' => 'emplo_emplf893mployer_ida',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:30:17
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_calls"] = array (
  'name' => 'gaur_candidates_activities_calls',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_calls',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:18
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_meetings"] = array (
  'name' => 'gaur_candidates_activities_meetings',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_meetings',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:19
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_notes"] = array (
  'name' => 'gaur_candidates_activities_notes',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_notes',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:19
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_tasks"] = array (
  'name' => 'gaur_candidates_activities_tasks',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_tasks',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:20
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_emails"] = array (
  'name' => 'gaur_candidates_activities_emails',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_emails',
  'source' => 'non-db',
);


// created: 2010-02-27 02:18:35
$dictionary["gaur_Candidates"]["fields"]["refer_references_gaur_candidates"] = array (
  'name' => 'refer_references_gaur_candidates',
  'type' => 'link',
  'relationship' => 'refer_references_gaur_candidates',
  'source' => 'non-db',
);



// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates"] = array (
  'name' => 'emplo_employer_gaur_candidates',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates_name"] = array (
  'name' => 'emplo_employer_gaur_candidates_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE',
  'save' => true,
  'id_name' => 'emplo_emplf893mployer_ida',
  'link' => 'emplo_employer_gaur_candidates',
  'table' => 'emplo_employer',
  'module' => 'emplo_Employer',
  'rname' => 'name',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_emplf893mployer_ida"] = array (
  'name' => 'emplo_emplf893mployer_ida',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:30:17
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_calls"] = array (
  'name' => 'gaur_candidates_activities_calls',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_calls',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:18
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_meetings"] = array (
  'name' => 'gaur_candidates_activities_meetings',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_meetings',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:19
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_notes"] = array (
  'name' => 'gaur_candidates_activities_notes',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_notes',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:19
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_tasks"] = array (
  'name' => 'gaur_candidates_activities_tasks',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_tasks',
  'source' => 'non-db',
);



// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates"] = array (
  'name' => 'emplo_employer_gaur_candidates',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates_name"] = array (
  'name' => 'emplo_employer_gaur_candidates_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE',
  'save' => true,
  'id_name' => 'emplo_emplf893mployer_ida',
  'link' => 'emplo_employer_gaur_candidates',
  'table' => 'emplo_employer',
  'module' => 'emplo_Employer',
  'rname' => 'name',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_emplf893mployer_ida"] = array (
  'name' => 'emplo_emplf893mployer_ida',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:30:17
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_calls"] = array (
  'name' => 'gaur_candidates_activities_calls',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_calls',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:18
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_meetings"] = array (
  'name' => 'gaur_candidates_activities_meetings',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_meetings',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:19
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_notes"] = array (
  'name' => 'gaur_candidates_activities_notes',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_notes',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:19
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_tasks"] = array (
  'name' => 'gaur_candidates_activities_tasks',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_tasks',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:20
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_emails"] = array (
  'name' => 'gaur_candidates_activities_emails',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_emails',
  'source' => 'non-db',
);


// created: 2010-02-27 02:18:35
$dictionary["gaur_Candidates"]["fields"]["refer_references_gaur_candidates"] = array (
  'name' => 'refer_references_gaur_candidates',
  'type' => 'link',
  'relationship' => 'refer_references_gaur_candidates',
  'source' => 'non-db',
);


// created: 2010-03-02 03:40:29
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_eval_evaluations"] = array (
  'name' => 'gaur_candidates_eval_evaluations',
  'type' => 'link',
  'relationship' => 'gaur_candidates_eval_evaluations',
  'source' => 'non-db',
);


// created: 2010-03-02 03:40:55
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_oss_job"] = array (
  'name' => 'gaur_candidates_oss_job',
  'type' => 'link',
  'relationship' => 'gaur_candidates_oss_job',
  'source' => 'non-db',
);



// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates"] = array (
  'name' => 'emplo_employer_gaur_candidates',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates_name"] = array (
  'name' => 'emplo_employer_gaur_candidates_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE',
  'save' => true,
  'id_name' => 'emplo_emplf893mployer_ida',
  'link' => 'emplo_employer_gaur_candidates',
  'table' => 'emplo_employer',
  'module' => 'emplo_Employer',
  'rname' => 'name',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_emplf893mployer_ida"] = array (
  'name' => 'emplo_emplf893mployer_ida',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:30:17
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_calls"] = array (
  'name' => 'gaur_candidates_activities_calls',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_calls',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:18
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_meetings"] = array (
  'name' => 'gaur_candidates_activities_meetings',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_meetings',
  'source' => 'non-db',
);



// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates"] = array (
  'name' => 'emplo_employer_gaur_candidates',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates_name"] = array (
  'name' => 'emplo_employer_gaur_candidates_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE',
  'save' => true,
  'id_name' => 'emplo_emplf893mployer_ida',
  'link' => 'emplo_employer_gaur_candidates',
  'table' => 'emplo_employer',
  'module' => 'emplo_Employer',
  'rname' => 'name',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_emplf893mployer_ida"] = array (
  'name' => 'emplo_emplf893mployer_ida',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);



// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates"] = array (
  'name' => 'emplo_employer_gaur_candidates',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates_name"] = array (
  'name' => 'emplo_employer_gaur_candidates_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE',
  'save' => true,
  'id_name' => 'emplo_emplf893mployer_ida',
  'link' => 'emplo_employer_gaur_candidates',
  'table' => 'emplo_employer',
  'module' => 'emplo_Employer',
  'rname' => 'name',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_emplf893mployer_ida"] = array (
  'name' => 'emplo_emplf893mployer_ida',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:30:17
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_calls"] = array (
  'name' => 'gaur_candidates_activities_calls',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_calls',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:18
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_meetings"] = array (
  'name' => 'gaur_candidates_activities_meetings',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_meetings',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:19
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_notes"] = array (
  'name' => 'gaur_candidates_activities_notes',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_notes',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:19
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_tasks"] = array (
  'name' => 'gaur_candidates_activities_tasks',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_tasks',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:20
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_emails"] = array (
  'name' => 'gaur_candidates_activities_emails',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_emails',
  'source' => 'non-db',
);



// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates"] = array (
  'name' => 'emplo_employer_gaur_candidates',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates_name"] = array (
  'name' => 'emplo_employer_gaur_candidates_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE',
  'save' => true,
  'id_name' => 'emplo_emplf893mployer_ida',
  'link' => 'emplo_employer_gaur_candidates',
  'table' => 'emplo_employer',
  'module' => 'emplo_Employer',
  'rname' => 'name',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_emplf893mployer_ida"] = array (
  'name' => 'emplo_emplf893mployer_ida',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:30:17
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_calls"] = array (
  'name' => 'gaur_candidates_activities_calls',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_calls',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:18
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_meetings"] = array (
  'name' => 'gaur_candidates_activities_meetings',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_meetings',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:19
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_notes"] = array (
  'name' => 'gaur_candidates_activities_notes',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_notes',
  'source' => 'non-db',
);



// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates"] = array (
  'name' => 'emplo_employer_gaur_candidates',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates_name"] = array (
  'name' => 'emplo_employer_gaur_candidates_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE',
  'save' => true,
  'id_name' => 'emplo_emplf893mployer_ida',
  'link' => 'emplo_employer_gaur_candidates',
  'table' => 'emplo_employer',
  'module' => 'emplo_Employer',
  'rname' => 'name',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_emplf893mployer_ida"] = array (
  'name' => 'emplo_emplf893mployer_ida',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:30:17
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_calls"] = array (
  'name' => 'gaur_candidates_activities_calls',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_calls',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:18
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_meetings"] = array (
  'name' => 'gaur_candidates_activities_meetings',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_meetings',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:19
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_notes"] = array (
  'name' => 'gaur_candidates_activities_notes',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_notes',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:19
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_tasks"] = array (
  'name' => 'gaur_candidates_activities_tasks',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_tasks',
  'source' => 'non-db',
);


// created: 2010-02-25 07:30:20
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_emails"] = array (
  'name' => 'gaur_candidates_activities_emails',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_emails',
  'source' => 'non-db',
);


// created: 2010-02-27 02:18:35
$dictionary["gaur_Candidates"]["fields"]["refer_references_gaur_candidates"] = array (
  'name' => 'refer_references_gaur_candidates',
  'type' => 'link',
  'relationship' => 'refer_references_gaur_candidates',
  'source' => 'non-db',
);


// created: 2010-03-02 03:40:29
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_eval_evaluations"] = array (
  'name' => 'gaur_candidates_eval_evaluations',
  'type' => 'link',
  'relationship' => 'gaur_candidates_eval_evaluations',
  'source' => 'non-db',
);


// created: 2010-03-02 03:40:55
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_oss_job"] = array (
  'name' => 'gaur_candidates_oss_job',
  'type' => 'link',
  'relationship' => 'gaur_candidates_oss_job',
  'source' => 'non-db',
);


// created: 2010-03-02 04:11:10
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_refer_referrals"] = array (
  'name' => 'gaur_candidates_refer_referrals',
  'type' => 'link',
  'relationship' => 'gaur_candidates_refer_referrals',
  'source' => 'non-db',
);



// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates"] = array (
  'name' => 'emplo_employer_gaur_candidates',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_employer_gaur_candidates_name"] = array (
  'name' => 'emplo_employer_gaur_candidates_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_EMPLO_EMPLOYER_GAUR_CANDIDATES_FROM_EMPLO_EMPLOYER_TITLE',
  'save' => true,
  'id_name' => 'emplo_emplf893mployer_ida',
  'link' => 'emplo_employer_gaur_candidates',
  'table' => 'emplo_employer',
  'module' => 'emplo_Employer',
  'rname' => 'name',
);


// created: 2010-02-25 07:29:07
$dictionary["gaur_Candidates"]["fields"]["emplo_emplf893mployer_ida"] = array (
  'name' => 'emplo_emplf893mployer_ida',
  'type' => 'link',
  'relationship' => 'emplo_employer_gaur_candidates',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-02-25 07:30:17
$dictionary["gaur_Candidates"]["fields"]["gaur_candidates_activities_calls"] = array (
  'name' => 'gaur_candidates_activities_calls',
  'type' => 'link',
  'relationship' => 'gaur_candidates_activities_calls',
  'source' => 'non-db',
);


?>