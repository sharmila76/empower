<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2010-03-02 04:11:10
$dictionary["Refer_Referrals"]["fields"]["gaur_candidates_refer_referrals"] = array (
  'name' => 'gaur_candidates_refer_referrals',
  'type' => 'link',
  'relationship' => 'gaur_candidates_refer_referrals',
  'source' => 'non-db',
  'side' => 'right',
);


// created: 2010-03-02 04:11:10
$dictionary["Refer_Referrals"]["fields"]["gaur_candidates_refer_referrals_name"] = array (
  'name' => 'gaur_candidates_refer_referrals_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_GAUR_CANDIDATES_REFER_REFERRALS_FROM_GAUR_CANDIDATES_TITLE',
  'save' => true,
  'id_name' => 'gaur_candi1200didates_ida',
  'link' => 'gaur_candidates_refer_referrals',
  'table' => 'gaur_candidates',
  'module' => 'gaur_Candidates',
  'rname' => 'name',
);


// created: 2010-03-02 04:11:10
$dictionary["Refer_Referrals"]["fields"]["gaur_candi1200didates_ida"] = array (
  'name' => 'gaur_candi1200didates_ida',
  'type' => 'link',
  'relationship' => 'gaur_candidates_refer_referrals',
  'source' => 'non-db',
  'side' => 'right',
);


?>