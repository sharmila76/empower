<?php 
//WARNING: The contents of this file are auto-generated


$mod_strings [ "LBL_GAUR_CANDIDATES_REFER_REFERRALS_FROM_GAUR_CANDIDATES_TITLE" ] = "Candidates" ;
$mod_strings ['VALUE' ]= 'Name of Candidate';
$mod_strings ['LBL_NAME' ]= 'Referral Name';
$mod_strings ['LBL_NAMEOFCANDIDATE' ]= 'Name of Candidate';
$mod_strings ['LBL_GAUR_CANDIDATES_REFER_REFERRALS_FROM_GAUR_CANDIDATES_TITLE' ]= 'Name of Candidate';

?>