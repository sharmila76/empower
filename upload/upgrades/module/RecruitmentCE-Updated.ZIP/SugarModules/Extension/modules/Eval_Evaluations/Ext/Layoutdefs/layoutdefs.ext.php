<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2010-03-02 03:40:29
$layout_defs["Eval_Evaluations"]["subpanel_setup"]["gaur_candidates_eval_evaluations"] = array (
  'order' => 100,
  'module' => 'gaur_Candidates',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GAUR_CANDIDATES_EVAL_EVALUATIONS_FROM_GAUR_CANDIDATES_TITLE',
  'get_subpanel_data' => 'gaur_candidates_eval_evaluations',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'People',
      'mode' => 'MultiSelect',
    ),
  ),
);



// created: 2010-03-02 03:40:29
$layout_defs["Eval_Evaluations"]["subpanel_setup"]["gaur_candidates_eval_evaluations"] = array (
  'order' => 100,
  'module' => 'gaur_Candidates',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_GAUR_CANDIDATES_EVAL_EVALUATIONS_FROM_GAUR_CANDIDATES_TITLE',
  'get_subpanel_data' => 'gaur_candidates_eval_evaluations',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'People',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2010-06-02 08:30:13
$layout_defs["Eval_Evaluations"]["subpanel_setup"]["eval_evaluations_calls"] = array (
  'order' => 100,
  'module' => 'Calls',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_EVAL_EVALUATIONS_CALLS_FROM_CALLS_TITLE',
  'get_subpanel_data' => 'eval_evaluations_calls',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);



//auto-generated file DO NOT EDIT
$layout_defs['Eval_Evaluations']['subpanel_setup']['gaur_candidates_eval_evaluations']['override_subpanel_name'] = 'Eval_Evaluationsdefault';

?>