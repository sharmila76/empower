<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2010-03-02 03:40:29
$dictionary["Eval_Evaluations"]["fields"]["gaur_candidates_eval_evaluations"] = array (
  'name' => 'gaur_candidates_eval_evaluations',
  'type' => 'link',
  'relationship' => 'gaur_candidates_eval_evaluations',
  'source' => 'non-db',
);



$dictionary["Eval_Evaluations"]["fields"]["name"]=array (
	 'required' => '1',
      'name' => 'name',
      'vname' => 'LBL_NAME',
      'type' => 'enum',
      'options' => 'evaluationname_list',
);

      

// created: 2010-03-02 03:40:29
$dictionary["Eval_Evaluations"]["fields"]["gaur_candidates_eval_evaluations"] = array (
  'name' => 'gaur_candidates_eval_evaluations',
  'type' => 'link',
  'relationship' => 'gaur_candidates_eval_evaluations',
  'source' => 'non-db',
);


// created: 2010-06-02 08:30:13
$dictionary["Eval_Evaluations"]["fields"]["eval_evaluations_calls"] = array (
  'name' => 'eval_evaluations_calls',
  'type' => 'link',
  'relationship' => 'eval_evaluations_calls',
  'source' => 'non-db',
  'vname' => 'LBL_EVAL_EVALUATIONS_CALLS_FROM_CALLS_TITLE',
);


?>