<?php 
//WARNING: The contents of this file are auto-generated


$mod_strings [ "LBL_GAUR_CANDIDATES_EVAL_EVALUATIONS_FROM_GAUR_CANDIDATES_TITLE" ] = "Candidates" ;


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_GAUR_CANDIDATES_EVAL_EVALUATIONS_FROM_GAUR_CANDIDATES_TITLE'] = 'Candidates';
$mod_strings['LBL_EVAL_EVALUATIONS_CALLS_FROM_CALLS_TITLE'] = 'Calls';
$mod_strings ['VALUE'] = 'Logical' ;
$mod_strings ['LBL_NAMEOFEVALUATOR'] = 'Name of Evaluator' ;
$mod_strings ['LBL_DATEOFEVALUATION'] = 'Date' ;
$mod_strings ['LBL_TIMEOFEVALUATION'] = 'Time' ;
$mod_strings ['LBL_CMARKS'] = 'C' ;
$mod_strings ['LBL_PHP'] = 'PHP' ;
$mod_strings ['LBL_ENGLISH'] = 'English' ;
$mod_strings ['LBL_LOGICAL'] = 'Logical' ;
$mod_strings ['LBL_MODE'] = 'Mode' ;
$mod_strings ['LBL_NEXTSTEPS'] = 'Next Steps' ;
$mod_strings ['LBL_RECOMMENDATIONS'] = 'Recommendations' ;
$mod_strings ['LBL_DESCRIPTION'] = 'Comments' ;
$mod_strings ['LBL_PANEL1'] = 'Selection Criteria(Scale of 1 to 10)' ;
$mod_strings ['LBL_PANEL2'] = 'Written Test' ;
$mod_strings ['LBL_PANEL3'] = 'Interview Summary' ;
$mod_strings ['LBL_NAME'] = 'Evaluation Name' ;
$mod_strings ['LBL_WRITTENENGLISH'] = 'Written English' ;
$mod_strings ['LBL_SPOKENENGLISH'] = 'Spoken English' ;
$mod_strings ['LBL_ANALYTICAL'] = 'Analytical' ;
$mod_strings ['LBL_PHP4'] = 'PHP4' ;
$mod_strings ['LBL_PHP5'] = 'PHP5' ;
$mod_strings ['LBL_MYSQL'] = 'MySQL' ;
$mod_strings ['LBL_DRUPAL'] = 'Drupal' ;
$mod_strings ['LBL_XCART'] = 'Xcart' ;
$mod_strings ['LBL_SUGARCRM'] = 'SugarCRM' ;
$mod_strings ['LBL_LINUX'] = 'Linux' ;
$mod_strings ['LBL_ZENDFRAMEWORK'] = 'Zend Framework' ;
$mod_strings ['LBL_SYMFONYFRAMEWORK'] = 'Symfony Framework' ;
$mod_strings ['LBL_CAKEPHP'] = 'Cake PHP' ;
$mod_strings ['LBL_JAVASCRIPT'] = 'Java Script' ;
$mod_strings ['LBL_JAVA'] = 'Java' ;
$mod_strings ['LBL_C_SPECIFIC'] = 'C' ;
$mod_strings ['LBL_OOPS'] = 'OOPS' ;
$mod_strings ['LBL_JOOMLA'] = 'Joomla' ;
$mod_strings ['LBL_CSS'] = 'CSS' ;
$mod_strings ['LBL_LOGICAL_CRITERIA'] = 'Logical' ;
$mod_strings ['LBL_CSELECTIONCRITERIA'] = 'C' ;
$mod_strings ['LBL_LOGICALSELECTION'] = 'Logical' ;
$mod_strings ['LBL_NAMEOFCANDIDATE'] = 'Name of Candidate' ;
$mod_strings ['LBL_CSELECTION'] = 'C' ;
$mod_strings ['LBL_LOGICAL1'] = 'Logical' ;
$mod_strings ['LBL_GAUR_CANDIDATES_EVAL_EVALUATIONS_SUBPANEL_TITLE'] = 'LBL_GAUR_CANDIDATES_EVAL_EVALUATIONS_SUBPANEL_TITLE' ;
?>