<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2009-11-05 02:10:16
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_project"] = array (
  'name' => 'oss_teammember_project',
  'type' => 'link',
  'relationship' => 'oss_teammember_project',
  'source' => 'non-db',
);


// created: 2009-11-05 02:12:12
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_project_1"] = array (
  'name' => 'oss_teammember_project_1',
  'type' => 'link',
  'relationship' => 'oss_teammember_project_1',
  'source' => 'non-db',
);


// created: 2009-11-06 03:35:04
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_leavemanagement"] = array (
  'name' => 'oss_teammember_oss_leavemanagement',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_leavemanagement',
  'source' => 'non-db',
);



// created: 2009-11-05 02:10:16
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_project"] = array (
  'name' => 'oss_teammember_project',
  'type' => 'link',
  'relationship' => 'oss_teammember_project',
  'source' => 'non-db',
);


// created: 2009-11-05 02:12:12
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_project_1"] = array (
  'name' => 'oss_teammember_project_1',
  'type' => 'link',
  'relationship' => 'oss_teammember_project_1',
  'source' => 'non-db',
);



// created: 2009-11-05 02:10:16
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_project"] = array (
  'name' => 'oss_teammember_project',
  'type' => 'link',
  'relationship' => 'oss_teammember_project',
  'source' => 'non-db',
);



// created: 2009-11-05 02:10:16
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_project"] = array (
  'name' => 'oss_teammember_project',
  'type' => 'link',
  'relationship' => 'oss_teammember_project',
  'source' => 'non-db',
);


// created: 2009-11-05 02:12:12
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_project_1"] = array (
  'name' => 'oss_teammember_project_1',
  'type' => 'link',
  'relationship' => 'oss_teammember_project_1',
  'source' => 'non-db',
);


// created: 2009-11-06 03:35:04
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_leavemanagement"] = array (
  'name' => 'oss_teammember_oss_leavemanagement',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_leavemanagement',
  'source' => 'non-db',
);


// created: 2009-11-06 05:40:07
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'name' => 'oss_teammember_oss_projectbudgetsheet',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_projectbudgetsheet',
  'source' => 'non-db',
);


// created: 2009-11-09 23:44:39
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_reimbursement"] = array (
  'name' => 'oss_teammember_oss_reimbursement',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_reimbursement',
  'source' => 'non-db',
);


// created: 2009-11-09 23:49:13
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_request_for_cash"] = array (
  'name' => 'oss_teammember_oss_request_for_cash',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_request_for_cash',
  'source' => 'non-db',
);



// created: 2009-10-27 13:41:40
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-27 13:41:40
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-27 14:04:23
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-27 14:04:23
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-27 14:04:23
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'name' => 'oss_teammember_oss_projectbudgetsheet',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_projectbudgetsheet',
  'source' => 'non-db',
);


// created: 2009-10-27 14:04:48
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-27 14:04:48
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-27 14:04:48
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'name' => 'oss_teammember_oss_projectbudgetsheet',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_projectbudgetsheet',
  'source' => 'non-db',
);


// created: 2009-10-27 14:04:49
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-27 14:04:49
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-27 14:04:49
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'name' => 'oss_teammember_oss_projectbudgetsheet',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_projectbudgetsheet',
  'source' => 'non-db',
);


// created: 2009-10-27 14:21:41
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-27 14:21:41
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-27 14:21:41
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'name' => 'oss_teammember_oss_projectbudgetsheet',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_projectbudgetsheet',
  'source' => 'non-db',
);


// created: 2009-10-27 15:16:12
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-27 15:16:12
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-27 15:16:12
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'name' => 'oss_teammember_oss_projectbudgetsheet',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_projectbudgetsheet',
  'source' => 'non-db',
);


// created: 2009-10-27 15:21:24
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-27 15:21:24
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-27 15:21:24
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'name' => 'oss_teammember_oss_projectbudgetsheet',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_projectbudgetsheet',
  'source' => 'non-db',
);


// created: 2009-10-27 15:21:26
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-27 15:21:26
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-27 15:21:26
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'name' => 'oss_teammember_oss_projectbudgetsheet',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_projectbudgetsheet',
  'source' => 'non-db',
);


// created: 2009-10-27 15:30:46
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-27 15:30:46
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-28 12:52:45
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-28 12:52:45
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-28 15:44:03
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-28 15:44:03
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-28 16:23:31
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-28 16:23:31
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-28 16:23:48
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-28 16:23:48
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-28 16:27:09
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-28 16:27:09
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-28 16:29:25
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-28 16:29:26
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-28 16:31:41
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-28 16:31:41
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-28 16:32:57
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-28 16:32:57
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-28 16:33:48
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-28 16:33:48
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-29 10:51:38
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-29 10:51:39
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-29 10:52:25
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-29 10:52:25
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);


// created: 2009-10-29 10:57:28
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-29 10:57:28
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);




// created: 2009-10-29 16:31:47
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_employementhistory"] = array (
  'name' => 'oss_teammember_oss_employementhistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_employementhistory',
  'source' => 'non-db',
);


// created: 2009-10-29 16:31:47
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_designationchangehistory"] = array (
  'name' => 'oss_teammember_oss_designationchangehistory',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_designationchangehistory',
  'source' => 'non-db',
);





// created: 2009-11-05 02:10:16
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_project"] = array (
  'name' => 'oss_teammember_project',
  'type' => 'link',
  'relationship' => 'oss_teammember_project',
  'source' => 'non-db',
);


// created: 2009-11-05 02:12:12
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_project_1"] = array (
  'name' => 'oss_teammember_project_1',
  'type' => 'link',
  'relationship' => 'oss_teammember_project_1',
  'source' => 'non-db',
);


// created: 2009-11-06 03:35:04
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_leavemanagement"] = array (
  'name' => 'oss_teammember_oss_leavemanagement',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_leavemanagement',
  'source' => 'non-db',
);


// created: 2009-11-06 05:40:07
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'name' => 'oss_teammember_oss_projectbudgetsheet',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_projectbudgetsheet',
  'source' => 'non-db',
);


// created: 2009-11-09 23:44:39
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_reimbursement"] = array (
  'name' => 'oss_teammember_oss_reimbursement',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_reimbursement',
  'source' => 'non-db',
);




$dictionary["OSS_TeamMember"]["fields"]["user_id1_c"] = array(    
    'required' => false,
    'name' => 'user_id1_c',
    'vname' => '',
    'type' => 'id',
    'massupdate' => 1,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => 0,
    'audited' => 0,
    'reportable' => 0,
    'len' => 36,
);

$dictionary["OSS_TeamMember"]["fields"]["report_to"] = array(    
    'required' => false,
    'source' => 'non-db',
    'name' => 'report_to',
    'vname' => 'LBL_REPORT_TO',
    'type' => 'relate',
    'massupdate' => 1,
    'comments' => '',
    'help' => '',
    'importable' => 'true',
    'duplicate_merge' => 'disabled',
    'duplicate_merge_dom_value' => '0',
    'audited' => 1,
    'reportable' => 1,
    'len' => '255',
    'id_name' => 'user_id1_c',
    'ext2' => 'Users',
    'module' => 'Users',
    'quicksearch' => 'enabled',
    'studio' => 'visible',
);



// created: 2009-11-05 02:10:16
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_project"] = array (
  'name' => 'oss_teammember_project',
  'type' => 'link',
  'relationship' => 'oss_teammember_project',
  'source' => 'non-db',
);


// created: 2009-11-05 02:12:12
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_project_1"] = array (
  'name' => 'oss_teammember_project_1',
  'type' => 'link',
  'relationship' => 'oss_teammember_project_1',
  'source' => 'non-db',
);


// created: 2009-11-06 03:35:04
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_leavemanagement"] = array (
  'name' => 'oss_teammember_oss_leavemanagement',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_leavemanagement',
  'source' => 'non-db',
);


// created: 2009-11-06 05:40:07
$dictionary["OSS_TeamMember"]["fields"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'name' => 'oss_teammember_oss_projectbudgetsheet',
  'type' => 'link',
  'relationship' => 'oss_teammember_oss_projectbudgetsheet',
  'source' => 'non-db',
);


?>