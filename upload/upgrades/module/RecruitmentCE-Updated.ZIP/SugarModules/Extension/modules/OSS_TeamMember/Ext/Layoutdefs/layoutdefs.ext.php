<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2009-11-05 02:10:16
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_project"] = array (
  'order' => 100,
  'module' => 'Project',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_PROJECT_FROM_PROJECT_TITLE',
  'get_subpanel_data' => 'oss_teammember_project',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Accounts',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-05 02:12:12
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_project_1"] = array (
  'order' => 100,
  'module' => 'Project',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_PROJECT_1_FROM_PROJECT_TITLE',
  'get_subpanel_data' => 'oss_teammember_project_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Accounts',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-06 03:35:04
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_leavemanagement"] = array (
  'order' => 100,
  'module' => 'OSS_LeaveManagement',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_LEAVEMANAGEMENT_FROM_OSS_LEAVEMANAGEMENT_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_leavemanagement',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_LeaveManagement',
      'mode' => 'MultiSelect',
    ),
  ),
);



// created: 2009-11-05 02:10:16
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_project"] = array (
  'order' => 100,
  'module' => 'Project',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_PROJECT_FROM_PROJECT_TITLE',
  'get_subpanel_data' => 'oss_teammember_project',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Accounts',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-05 02:12:12
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_project_1"] = array (
  'order' => 100,
  'module' => 'Project',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_PROJECT_1_FROM_PROJECT_TITLE',
  'get_subpanel_data' => 'oss_teammember_project_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Accounts',
      'mode' => 'MultiSelect',
    ),
  ),
);



// created: 2009-11-05 02:10:16
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_project"] = array (
  'order' => 100,
  'module' => 'Project',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_PROJECT_FROM_PROJECT_TITLE',
  'get_subpanel_data' => 'oss_teammember_project',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Accounts',
      'mode' => 'MultiSelect',
    ),
  ),
);



// created: 2009-11-05 02:10:16
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_project"] = array (
  'order' => 100,
  'module' => 'Project',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_PROJECT_FROM_PROJECT_TITLE',
  'get_subpanel_data' => 'oss_teammember_project',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Accounts',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-05 02:12:12
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_project_1"] = array (
  'order' => 100,
  'module' => 'Project',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_PROJECT_1_FROM_PROJECT_TITLE',
  'get_subpanel_data' => 'oss_teammember_project_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Accounts',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-06 03:35:04
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_leavemanagement"] = array (
  'order' => 100,
  'module' => 'OSS_LeaveManagement',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_LEAVEMANAGEMENT_FROM_OSS_LEAVEMANAGEMENT_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_leavemanagement',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_LeaveManagement',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-06 05:40:07
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'order' => 100,
  'module' => 'OSS_ProjectBudgetSheet',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_PROJECTBUDGETSHEET_FROM_OSS_PROJECTBUDGETSHEET_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_projectbudgetsheet',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_ProjectBudgetSheet',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-09 23:44:39
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_reimbursement"] = array (
  'order' => 100,
  'module' => 'OSS_Reimbursement',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_REIMBURSEMENT_FROM_OSS_REIMBURSEMENT_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_reimbursement',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_Reimbursement',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-09 23:49:13
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_request_for_cash"] = array (
  'order' => 100,
  'module' => 'OSS_Request_For_Cash',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_REQUEST_FOR_CASH_FROM_OSS_REQUEST_FOR_CASH_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_request_for_cash',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_Request_For_Cash',
      'mode' => 'MultiSelect',
    ),
  ),
);



// created: 2009-10-27 13:41:40
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 13:41:40
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 14:04:23
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 14:04:23
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 14:04:23
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'order' => 100,
  'module' => 'OSS_ProjectBudgetSheet',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_PROJECTBUDGETSHEET_FROM_OSS_PROJECTBUDGETSHEET_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_projectbudgetsheet',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_ProjectBudgetSheet',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 14:04:48
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 14:04:48
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 14:04:48
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'order' => 100,
  'module' => 'OSS_ProjectBudgetSheet',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_PROJECTBUDGETSHEET_FROM_OSS_PROJECTBUDGETSHEET_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_projectbudgetsheet',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_ProjectBudgetSheet',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 14:04:49
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 14:04:49
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 14:04:49
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'order' => 100,
  'module' => 'OSS_ProjectBudgetSheet',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_PROJECTBUDGETSHEET_FROM_OSS_PROJECTBUDGETSHEET_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_projectbudgetsheet',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_ProjectBudgetSheet',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 14:21:41
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 14:21:41
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 14:21:41
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'order' => 100,
  'module' => 'OSS_ProjectBudgetSheet',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_PROJECTBUDGETSHEET_FROM_OSS_PROJECTBUDGETSHEET_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_projectbudgetsheet',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_ProjectBudgetSheet',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 15:16:12
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 15:16:12
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 15:16:12
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'order' => 100,
  'module' => 'OSS_ProjectBudgetSheet',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_PROJECTBUDGETSHEET_FROM_OSS_PROJECTBUDGETSHEET_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_projectbudgetsheet',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_ProjectBudgetSheet',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 15:21:24
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 15:21:24
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 15:21:24
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'order' => 100,
  'module' => 'OSS_ProjectBudgetSheet',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_PROJECTBUDGETSHEET_FROM_OSS_PROJECTBUDGETSHEET_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_projectbudgetsheet',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_ProjectBudgetSheet',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 15:21:26
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 15:21:26
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 15:21:26
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'order' => 100,
  'module' => 'OSS_ProjectBudgetSheet',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_PROJECTBUDGETSHEET_FROM_OSS_PROJECTBUDGETSHEET_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_projectbudgetsheet',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_ProjectBudgetSheet',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 15:30:46
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-27 15:30:46
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-28 12:52:45
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-28 12:52:45
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-28 15:44:03
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
);


// created: 2009-10-28 15:44:03
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
);


// created: 2009-10-28 16:23:31
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
);


// created: 2009-10-28 16:23:31
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
);


// created: 2009-10-28 16:23:48
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-28 16:23:48
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-28 16:27:09
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-28 16:27:09
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-28 16:29:25
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
);


// created: 2009-10-28 16:29:25
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
);


// created: 2009-10-28 16:31:41
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-28 16:31:41
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-28 16:32:57
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-28 16:32:57
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-28 16:33:48
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
);


// created: 2009-10-28 16:33:48
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
);


// created: 2009-10-29 10:51:38
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-29 10:51:38
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-29 10:52:25
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
);


// created: 2009-10-29 10:52:25
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
);


// created: 2009-10-29 10:57:27
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-29 10:57:27
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-29 10:57:27
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_skillset"] = array (
  'order' => 100,
  'module' => 'OSS_SkillSet',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_SKILLSET_FROM_OSS_SKILLSET_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_skillset',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_SkillSet',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-29 16:31:46
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_employementhistory"] = array (
  'order' => 100,
  'module' => 'OSS_EmployementHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_EMPLOYEMENTHISTORY_FROM_OSS_EMPLOYEMENTHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_employementhistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_EmployementHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-29 16:31:47
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_designationchangehistory"] = array (
  'order' => 100,
  'module' => 'OSS_DesignationChangeHistory',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_DESIGNATIONCHANGEHISTORY_FROM_OSS_DESIGNATIONCHANGEHISTORY_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_designationchangehistory',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_DesignationChangeHistory',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-10-29 16:31:47
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_skillset"] = array (
  'order' => 100,
  'module' => 'OSS_SkillSet',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_SKILLSET_FROM_OSS_SKILLSET_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_skillset',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_SkillSet',
      'mode' => 'MultiSelect',
    ),
  ),
);



// created: 2009-11-05 02:10:16
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_project"] = array (
  'order' => 100,
  'module' => 'Project',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_PROJECT_FROM_PROJECT_TITLE',
  'get_subpanel_data' => 'oss_teammember_project',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Accounts',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-05 02:12:12
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_project_1"] = array (
  'order' => 100,
  'module' => 'Project',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_PROJECT_1_FROM_PROJECT_TITLE',
  'get_subpanel_data' => 'oss_teammember_project_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Accounts',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-06 03:35:04
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_leavemanagement"] = array (
  'order' => 100,
  'module' => 'OSS_LeaveManagement',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_LEAVEMANAGEMENT_FROM_OSS_LEAVEMANAGEMENT_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_leavemanagement',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_LeaveManagement',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-06 05:40:07
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'order' => 100,
  'module' => 'OSS_ProjectBudgetSheet',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_PROJECTBUDGETSHEET_FROM_OSS_PROJECTBUDGETSHEET_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_projectbudgetsheet',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_ProjectBudgetSheet',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-09 23:44:39
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_reimbursement"] = array (
  'order' => 100,
  'module' => 'OSS_Reimbursement',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_REIMBURSEMENT_FROM_OSS_REIMBURSEMENT_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_reimbursement',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_Reimbursement',
      'mode' => 'MultiSelect',
    ),
  ),
);



// created: 2009-11-05 02:10:16
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_project"] = array (
  'order' => 100,
  'module' => 'Project',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_PROJECT_FROM_PROJECT_TITLE',
  'get_subpanel_data' => 'oss_teammember_project',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Accounts',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-05 02:12:12
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_project_1"] = array (
  'order' => 100,
  'module' => 'Project',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_PROJECT_1_FROM_PROJECT_TITLE',
  'get_subpanel_data' => 'oss_teammember_project_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'Accounts',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-06 03:35:04
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_leavemanagement"] = array (
  'order' => 100,
  'module' => 'OSS_LeaveManagement',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_LEAVEMANAGEMENT_FROM_OSS_LEAVEMANAGEMENT_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_leavemanagement',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_LeaveManagement',
      'mode' => 'MultiSelect',
    ),
  ),
);


// created: 2009-11-06 05:40:07
$layout_defs["OSS_TeamMember"]["subpanel_setup"]["oss_teammember_oss_projectbudgetsheet"] = array (
  'order' => 100,
  'module' => 'OSS_ProjectBudgetSheet',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_OSS_TEAMMEMBER_OSS_PROJECTBUDGETSHEET_FROM_OSS_PROJECTBUDGETSHEET_TITLE',
  'get_subpanel_data' => 'oss_teammember_oss_projectbudgetsheet',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopCreateButton',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'popup_module' => 'OSS_ProjectBudgetSheet',
      'mode' => 'MultiSelect',
    ),
  ),
);


?>