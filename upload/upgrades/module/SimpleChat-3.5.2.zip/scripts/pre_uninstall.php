<?php
if(!defined('sugarEntry'))define('sugarEntry', true);

function pre_uninstall() {
  	global $db;
    $db = &DBManagerFactory::getInstance();

$is_mssql= false;
if (strtolower($db->dbType)=='mssql') {
	$is_mssql= true;
}

echo '<script type="text/javascript">
    YAHOO.util.Event.onDOMReady(function(){
      oEl= document.getElementById("beforeChat");
      oEl.style.display="none";
    });
</script>';

	if ($is_mssql) { //start MSSQL

		$un="
		IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'messages_online') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
		DROP TABLE messages_online";
		$db->query($un);

		if ($_POST['remove_tables']=='true') {
		  $un="
		  IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'messages') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
		  DROP TABLE messages";
		  $db->query($un);

		  $un="
          IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'messages_history') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
		  DROP TABLE messages_history";
		  $db->query($un);

		  $un="
          IF EXISTS (SELECT * FROM sysobjects WHERE id = object_id(N'messages_config') AND OBJECTPROPERTY(id, N'IsUserTable') = 1)
		  DROP TABLE messages_config";
		  $db->query($un);
		}

	} //end MSSQL
	else {
	 	$un="DROP TABLE IF EXISTS messages_online";
		$db->query($un);

		if ($_POST['remove_tables']=='true') {
		  $un="DROP TABLE IF EXISTS messages, messages_history, messages_config";
		  $db->query($un);
		}
	}

}
?>
