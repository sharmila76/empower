<?php

$app_list_strings['call_status_dom']=array (
  'Planned' => 'Planned',
  'Held' => 'Held',
  'Not Held' => 'Not Held',
  'Missed' => 'Missed',
  'In Limbo' => 'In Limbo',
);