<?php
// created: 2009-06-18 17:38:48
$mod_strings = array (
    'VALUE' => 'CallerId',
    'LBL_ASTERISK_CALLER_ID' => 'CallerId',
    'LBL_ASTERISK_CALL_ID' => 'PBX Call ID',
    'LBL_ASTERISK_RECORDING_BUTTONS' => "Recording",
    'LBL_ASTERISK_INBOUND_EXT' => "Inbound Ext.",
    'LBL_ASTERISK_USER_EXT' => 'User Ext.'
);
?>
