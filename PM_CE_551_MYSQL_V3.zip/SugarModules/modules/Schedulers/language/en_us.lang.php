<?php
$mod_strings ['LBL_RUNPROCESSMANAGER']='runProcessManager';
?>