<?php

function pre_uninstall(){
	require_once('data/SugarBean.php');
		
	$focus = new SugarBean();
	$query = "drop table pm_process_completed_process";
	$focus->db->query($query, true);
	$query = "drop table pm_process_filter_table";
	$focus->db->query($query, true);
	$query = "drop table pm_processmanager_entry_table";
	$focus->db->query($query, true);
	$query = "drop table pm_process_task_call_defs";
	$focus->db->query($query, true);
	$query = "drop table pm_process_task_email_defs";
	$focus->db->query($query, true);
	$query = "drop table pm_process_task_task_defs";
	$focus->db->query($query, true);
}
?>