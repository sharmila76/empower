<?php

function pre_install(){

   require_once('include/utils.php');
   check_logic_hook_file("Leads", "after_save", array(1, "INSERT_INTO_PM_ENTRY_TABLE","modules/PM_ProcessManager/insertIntoPmEntryTable.php", "insertIntoPmEntryTable","setPmEntryTable"));
   check_logic_hook_file("Opportunities", "after_save", array(1, "INSERT_INTO_PM_ENTRY_TABLE","modules/PM_ProcessManager/insertIntoPmEntryTable.php", "insertIntoPmEntryTable","setPmEntryTable"));
   check_logic_hook_file("Accounts", "after_save", array(1, "INSERT_INTO_PM_ENTRY_TABLE","modules/PM_ProcessManager/insertIntoPmEntryTable.php", "insertIntoPmEntryTable","setPmEntryTable"));
   check_logic_hook_file("Contacts", "after_save", array(1, "INSERT_INTO_PM_ENTRY_TABLE","modules/PM_ProcessManager/insertIntoPmEntryTable.php", "insertIntoPmEntryTable","setPmEntryTable"));
   check_logic_hook_file("Cases", "after_save", array(1, "INSERT_INTO_PM_ENTRY_TABLE","modules/PM_ProcessManager/insertIntoPmEntryTable.php", "insertIntoPmEntryTable","setPmEntryTable"));
   check_logic_hook_file("Bugs", "after_save", array(1, "INSERT_INTO_PM_ENTRY_TABLE","modules/PM_ProcessManager/insertIntoPmEntryTable.php", "insertIntoPmEntryTable","setPmEntryTable"));
   check_logic_hook_file("Project", "after_save", array(1, "INSERT_INTO_PM_ENTRY_TABLE","modules/PM_ProcessManager/insertIntoPmEntryTable.php", "insertIntoPmEntryTable","setPmEntryTable"));
   check_logic_hook_file("Tasks", "after_save", array(1, "INSERT_INTO_PM_ENTRY_TABLE","modules/PM_ProcessManager/insertIntoPmEntryTable.php", "insertIntoPmEntryTable","setPmEntryTable"));


//Go and see if any of the pm tables exist and drop them if so
//This happens on failed installs
require_once('data/SugarBean.php');
$focus = new SugarBean();
	//pm_process_completed_process
	$query = "SHOW TABLES LIKE 'pm_process_completed_process'";
	$results = $focus->db->query($query, true);
	while($row = $focus->db->fetchByAssoc($results))
		{
		$query = "drop table pm_process_completed_process";
		$focus->db->query($query, true);
		}

	//pm_process_filter_table
	$query = "SHOW TABLES LIKE 'pm_process_filter_table'";
	$results = $focus->db->query($query, true);
	while($row = $focus->db->fetchByAssoc($results))
		{
		$query = "drop table pm_process_filter_table";
		$focus->db->query($query, true);
		}
	//pm_processmanager_entry_table
	$query = "SHOW TABLES LIKE 'pm_processmanager_entry_table'";
	$results = $focus->db->query($query, true);
	while($row = $focus->db->fetchByAssoc($results))
		{
		$query = "drop table pm_processmanager_entry_table";
		$focus->db->query($query, true);
		}
	//pm_process_task_call_defs
	$query = "SHOW TABLES LIKE 'pm_process_task_call_defs'";
	$results = $focus->db->query($query, true);
	while($row = $focus->db->fetchByAssoc($results))
		{
		$query = "drop table pm_process_task_call_defs";
		$focus->db->query($query, true);
		}
	//pm_process_task_email_defs
	$query = "SHOW TABLES LIKE 'pm_process_task_email_defs'";
	$results = $focus->db->query($query, true);
	while($row = $focus->db->fetchByAssoc($results))
		{
		$query = "drop table pm_process_task_email_defs";
		$focus->db->query($query, true);
		}
	//pm_process_task_task_defs
	$query = "SHOW TABLES LIKE 'pm_process_task_task_defs'";
	$results = $focus->db->query($query, true);
	while($row = $focus->db->fetchByAssoc($results))
		{
		$query = "drop table pm_process_task_task_defs";
		$focus->db->query($query, true);
		}					


//Now update the Scheduler for the job		
$file = 'custom/modules/Schedulers/_AddJobsHere.php';
$newfile = 'custom/modules/Schedulers/_AddJobsHere_Orig.php';

	$replace1 = "var_dump(\$job_strings);
				\$job_strings[]='runProcessManager';
				var_dump(\$job_strings);
				function runProcessManager() {
				require_once('modules/PM_ProcessManager/ProcessManagerEngine.php');
				\$processManager = new ProcessManagerEngine();
				\$processManager->processManagerMain();
				return true;
				} \n
				?>";

	$replace2 = "<?php
				var_dump(\$job_strings);
				\$job_strings[]='runProcessManager';
				var_dump(\$job_strings);
				function runProcessManager() {
				require_once('modules/PM_ProcessManager/ProcessManagerEngine.php');
				\$processManager = new ProcessManagerEngine();
				\$processManager->processManagerMain();
				return true;
				} \n
				?>";
	$language1 = "\$mod_strings ['LBL_RUNPROCESSMANAGER']='runProcessManager';
		     ?>";
	$language2 = "<?php
		     \$mod_strings ['LBL_RUNPROCESSMANAGER']='runProcessManager';
		     ?>";		     				

//Check to see if the file exists for Add Jobs Here
if (file_exists($file)) {
	copy($file, $newfile);
	//Now append the contents of the Process Manager job to the end of the file
	//First make sure that the runProcessManager code is not already there
	$file = 'custom/modules/Schedulers/_AddJobsHere.php';
	$fp = fopen($file, 'r+');
	$str = "";
    $fileContents = fread($fp, filesize($file)); 
    fclose($fp);
    //Now see if runProcessManager is already in there
	$pos = strpos($fileContents, 'runProcessManager'); 
	if ($pos === false) {
		//Add the entry for Process Manager to the End of the File
		$fp = fopen($file, 'r+');
		while(1)
			{
				//read line
				$line = fgets($fp);
				//if end of file reached then stop reading anymore
				if($line == null)break;
				
				//Do first replacement
				if(preg_match("/\?>/", $line))
				{
					$new_line = preg_replace("/\?>/",$replace1,$line);
					$str .= $new_line;
				}
				else
				{
					//set file content to a string
					$str .= $line;
				}
				
			}
	//set pointer back to beginning
	rewind($fp);
	fclose($fp);
	//delete everything in the file.
	$handle = fopen('custom/modules/Schedulers/_AddJobsHere.php', 'w');

	//write everything back to file with the updated gpa line
	fwrite($handle, $str);
	fclose($handle); 
	}
}
else{
	//File does not exist so make sure that we have a directory structure in place and create the file
	mkdir_recursive('custom/modules/Schedulers');
	//Now create the file
	$handle = fopen('custom/modules/Schedulers/_AddJobsHere.php', 'a+');
	fwrite($handle, $replace2);
	fclose($handle);
}


//Now do the Language File
$file = 'custom/modules/Schedulers/language/en_us.lang.php';
if (file_exists($file)) {
	//Now append the contents of the Process Manager job to the end of the file
	//First make sure that the runProcessManager code is not already there
	$file = 'custom/modules/Schedulers/language/en_us.lang.php';
	$fp = fopen($file, 'r+');
	$str = "";
    $fileContents = fread($fp, filesize($file)); 
    fclose($fp);
    //Now see if runProcessManager is already in there
	$pos = strpos($fileContents, 'runProcessManager'); 
	if ($pos === false) {
		//Add the entry for Process Manager to the End of the File
		$fp = fopen($file, 'r+');
		while(1)
			{
				//read line
				$line = fgets($fp);
				//if end of file reached then stop reading anymore
				if($line == null)break;
				
				//Do first replacement
				if(preg_match("/\?>/", $line))
				{
					$new_line = preg_replace("/\?>/",$language1,$line);
					$str .= $new_line;
				}
				else
				{
					//set file content to a string
					$str .= $line;
				}
				
			}
	//set pointer back to beginning
	rewind($fp);
	fclose($fp);
	//delete everything in the file.
	$handle = fopen('custom/modules/Schedulers/language/en_us.lang.php', 'w');

	//write everything back to file with the updated gpa line
	fwrite($handle, $str);
	fclose($handle); 
	}
}
else{
	//File does not exist so make sure that we have a directory structure in place and create the file
	mkdir_recursive('custom/modules/Schedulers/language');
	//Now create the file
	$handle = fopen('custom/modules/Schedulers/language/en_us.lang.php', 'a+');
	fwrite($handle, $language2);
	fclose($handle);
}

	
}

?>