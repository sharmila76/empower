<?php
require_once('data/SugarBean.php');
$focus = new SugarBean();
$query = "CREATE TABLE `pm_process_completed_process` (
  `id` varchar(36) NOT NULL default '',
  `object_id` varchar(36) NOT NULL default '',
  `object_type` varchar(45) default NULL,
  `process_id` varchar(36) default NULL,
  `stage_id` varchar(36) default NULL,
  `task_id` varchar(36) default NULL,
  `process_complete` tinyint(1) unsigned default '0',
  PRIMARY KEY  (`id`),
  KEY `idx_object_id` (`object_id`)
)";
$focus->db->query($query, true);

$query = "CREATE TABLE `pm_process_filter_table` (
  `id` varchar(36) NOT NULL default '',
  `process_id` varchar(36) NOT NULL default '',
  `status` varchar(35) NOT NULL default '',
  `field_name` varchar(45) NOT NULL default '',
  `field_value` varchar(45) NOT NULL default '',
  `contact_role` varchar(45) NOT NULL default '',
  `field_operator` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
)";
$focus->db->query($query, true);

$query = "CREATE TABLE `pm_processmanager_entry_table` (
  `id` varchar(36) NOT NULL default '',
  `object_id` varchar(36) default NULL,
  `object_type` varchar(45) default NULL,
  `object_event` varchar(45) default NULL,
  PRIMARY KEY  (`id`)
)";
$focus->db->query($query, true);

$query = "CREATE TABLE  `pm_process_task_call_defs` (
  `id` varchar(36) NOT NULL default '',
  `task_id` varchar(36) NOT NULL default '',
  `call_subject` varchar(45) default NULL,
  `start_delay_minutes` int(11) default '0',
  `start_delay_hours` int(11) default '0',
  `start_delay_days` int(11) default '0',
  `reminder_time` int(11) default '-1',
  `call_description` text,
  `start_delay_type` varchar(45) default NULL,
  `start_delay_months` int(11) default '0',
  `start_delay_years` int(11) default '0',
  PRIMARY KEY  (`id`)
)";
$focus->db->query($query, true);

$query = "CREATE TABLE  `pm_process_task_email_defs` (
  `id` varchar(36) NOT NULL default '',
  `email_template_name` varchar(100) default NULL,
  `email_template_id` varchar(36) default NULL,
  `task_id` varchar(36) default NULL,
  `contact_role` varchar(45) default NULL,
  `send_email_to_caseopp_account` int(11) default '0',
  PRIMARY KEY  (`id`)
)";
$focus->db->query($query, true);

$query = "CREATE TABLE  `pm_process_task_task_defs` (
  `id` varchar(36) NOT NULL default '',
  `task_id` varchar(36) NOT NULL default '',
  `task_subject` varchar(45) default NULL,
  `task_priority` varchar(15) default NULL,
  `due_date_delay_minutes` int(11) default '0',
  `due_date_delay_hours` int(11) default '0',
  `due_date_delay_days` int(11) default '0',
  `due_date_delay_type` varchar(45) default NULL,
  `due_date_delay_months` int(11) default '0',
  `due_date_delay_years` int(11) default '0',
  `task_description` text,
  PRIMARY KEY  (`id`)
)";
$focus->db->query($query, true);

//Now alter the tasks table and add the field for process manager generated tasks
$tasksTableLoaded = false;
$query = "SHOW columns from tasks";
$results = $focus->db->query($query, true);
while($row = $focus->db->fetchByAssoc($results))
	{
		$columnName = $row['Field'];
		if($columnName == 'is_pm_created_task'){
			$tasksTableLoaded = true;		
		}

	}
if(!$tasksTableLoaded){	
	$query = "ALTER TABLE tasks ADD COLUMN is_pm_created_task tinyint(1) default '0'";
	$focus->db->query($query, true);
}
?>